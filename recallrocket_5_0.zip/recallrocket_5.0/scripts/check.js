'use strict';
// Dependency-free static check: every JS file must parse, and no server file may use console.log of secrets or eval.
const fs = require('fs'), path = require('path'), { spawnSync } = require('child_process');
const root = path.join(__dirname, '..'); let bad = 0;
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e =>
  e.name === 'node_modules' || e.name.startsWith('.') ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
for (const f of walk(root).filter(f => f.endsWith('.js'))) {
  const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
  if (r.status) { bad++; console.error(`SYNTAX ${path.relative(root, f)}\n${r.stderr}`); }
  const src = fs.readFileSync(f, 'utf8');
  if (/\beval\s*\(|new Function\s*\(/.test(src) && !f.endsWith('check.js')) { bad++; console.error(`UNSAFE eval/new Function in ${path.relative(root, f)}`); }
}
console.log(bad ? `${bad} problem(s) found` : 'All files parse; no eval found.'); process.exit(bad ? 1 : 0);
