/* RecallRocket 3.0 · FX engine: cursor, particles, background, reveals, text effects, sound.
   Pure vanilla JS, no dependencies. Respects prefers-reduced-motion and touch devices. */
(() => {
  const $ = s => document.querySelector(s);
  const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const FINE = matchMedia('(hover: hover) and (pointer: fine)').matches;
  const root = document.documentElement;
  let prefs = { cursor: true, bg: true, sound: false, accent: 'indigo', goal: 10 };
  try { Object.assign(prefs, JSON.parse(localStorage.getItem('rr-prefs') || '{}')); } catch {}
  const save = () => { try { localStorage.setItem('rr-prefs', JSON.stringify(prefs)); } catch {} };
  const ACCENTS = { indigo: ['#4338ff', '#7b83ff'], violet: ['#7c3aed', '#a78bfa'], teal: ['#0d9488', '#2dd4bf'], rose: ['#e11d48', '#fb7185'], amber: ['#d97706', '#fbbf24'] };

  // ---------- colours ----------
  const C = { accent: '#4338ff', flame: '#ff5a1f', good: '#0f9d6e' };
  const rgb = h => { h = h.replace('#', ''); if (h.length === 3) h = [...h].map(x => x + x).join(''); const n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  function refreshColors() {
    const cs = getComputedStyle(root), g = k => cs.getPropertyValue(k).trim();
    C.accent = g('--accent') || C.accent; C.flame = g('--flame') || C.flame; C.good = g('--good') || C.good;
    C.rgb = rgb(C.accent.startsWith('#') ? C.accent : '#4338ff'); C.dark = root.dataset.theme === 'dark';
  }
  function applyAccent() {
    const st = root.style;
    if (prefs.accent === 'indigo' || !ACCENTS[prefs.accent]) { st.removeProperty('--accent'); st.removeProperty('--back'); }
    else { const c = ACCENTS[prefs.accent][root.dataset.theme === 'dark' ? 1 : 0]; st.setProperty('--accent', c); st.setProperty('--back', c); }
    refreshColors();
  }
  new MutationObserver(applyAccent).observe(root, { attributes: true, attributeFilter: ['data-theme'] });

  // ---------- splash ----------
  const splash = $('#splash');
  function hideSplash() { if (!splash) return; splash.classList.add('out'); setTimeout(() => splash.remove(), 700); }
  if (RM || sessionStorage.getItem('rr-splash')) splash && splash.remove();
  else { try { sessionStorage.setItem('rr-splash', '1'); } catch {} setTimeout(hideSplash, 1250); }

  // ---------- canvases ----------
  const fxCv = $('#fx'), fxC = fxCv.getContext('2d'), bgCv = $('#bg'), bgC = bgCv.getContext('2d');
  let W = innerWidth, H = innerHeight;
  function resize() {
    const dpr = Math.min(2, devicePixelRatio || 1); W = innerWidth; H = innerHeight;
    [[fxCv, fxC], [bgCv, bgC]].forEach(([c, x]) => { c.width = W * dpr; c.height = H * dpr; x.setTransform(dpr, 0, 0, dpr, 0, 0); });
    initBg();
  }

  // ---------- particles (trail, burst, confetti) ----------
  const P = []; let pRaf = 0, last = 0;
  const rand = (a, b) => a + Math.random() * (b - a);
  const col = () => Math.random() < .28 ? C.flame : C.accent;
  function spawn(p) { P.push(p); if (!pRaf) { last = performance.now(); pRaf = requestAnimationFrame(pTick); } }
  function pTick(t) {
    const dt = Math.min(40, t - last) / 16.67; last = t; fxC.clearRect(0, 0, W, H);
    for (let i = P.length - 1; i >= 0; i--) {
      const p = P[i]; p.age += dt * 16.67; const k = p.age / p.life;
      if (k >= 1 || p.y > H + 40) { P.splice(i, 1); continue; }
      p.vy += (p.g || 0) * dt; p.vx *= p.drag || 1; p.vy *= p.drag || 1; p.x += p.vx * dt; p.y += p.vy * dt;
      fxC.globalAlpha = p.kind === 'conf' ? Math.min(1, (1 - k) * 2.2) : (1 - k);
      fxC.fillStyle = p.c;
      if (p.kind === 'conf') { p.rot += p.vr * dt; fxC.save(); fxC.translate(p.x, p.y); fxC.rotate(p.rot); fxC.scale(1, Math.cos(p.age / 120 + p.ph)); fxC.fillRect(-p.s, -p.s * .5, p.s * 2, p.s); fxC.restore(); }
      else { const r = p.s * (1 - k * .7); fxC.beginPath(); fxC.arc(p.x, p.y, r, 0, 6.283); fxC.fill(); fxC.globalAlpha *= .22; fxC.beginPath(); fxC.arc(p.x, p.y, r * 2.6, 0, 6.283); fxC.fill(); }
    }
    fxC.globalAlpha = 1;
    pRaf = P.length ? requestAnimationFrame(pTick) : (fxC.clearRect(0, 0, W, H), 0);
  }
  function burst(x, y, n = 16) {
    if (RM) return;
    for (let i = 0; i < n; i++) { const a = rand(0, 6.283), v = rand(1.5, 5); spawn({ kind: 'spark', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: .06, drag: .96, s: rand(1.6, 3.6), life: rand(450, 900), age: 0, c: col() }); }
  }
  function confetti(n = 150) {
    if (RM) return; const cols = [C.accent, C.flame, C.good, '#ffc83d', '#ff5ea8', '#37c8ff'];
    for (let i = 0; i < n; i++) {
      const left = i % 2, x = left ? -10 : W + 10, a = left ? rand(-1.3, -.35) : rand(-2.8, -1.85), v = rand(9, 19);
      spawn({ kind: 'conf', x, y: H * .75, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: .33, drag: .985, s: rand(4, 8), rot: rand(0, 6), vr: rand(-.2, .2), ph: rand(0, 6), life: rand(2600, 4200), age: 0, c: cols[i % cols.length] });
    }
  }

  // ---------- animated background (constellation + aurora blobs) ----------
  let pts = [], bgRaf = 0, mx = W / 2, my = H / 2;
  function initBg() { const n = Math.min(70, Math.round(W * H / 24000)); pts = Array.from({ length: n }, () => ({ x: rand(0, W), y: rand(0, H), vx: rand(-.25, .25), vy: rand(-.25, .25), r: rand(1, 2.2) })); }
  function bgTick(t) {
    if (!prefs.bg || RM) { bgC.clearRect(0, 0, W, H); bgRaf = 0; return; }
    bgRaf = requestAnimationFrame(bgTick); if (document.hidden) return;
    bgC.clearRect(0, 0, W, H);
    const [r, g, b] = C.rgb || [67, 56, 255], a = C.dark ? 1.5 : 1;
    [[.28, .3, 0, C.accent, .16], [.75, .25, 2, C.flame, .09], [.55, .85, 4, C.good, .07]].forEach(([bx, by, ph, c, al]) => {
      const x = W * (bx + .12 * Math.sin(t / 9000 + ph)), y = H * (by + .1 * Math.cos(t / 11000 + ph)), rad = Math.max(W, H) * .42;
      const gr = bgC.createRadialGradient(x, y, 0, x, y, rad), [cr, cg, cb] = rgb(c.startsWith('#') ? c : '#4338ff');
      gr.addColorStop(0, `rgba(${cr},${cg},${cb},${al * a})`); gr.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      bgC.fillStyle = gr; bgC.fillRect(0, 0, W, H);
    });
    for (const p of pts) {
      p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > W) p.vx *= -1; if (p.y < 0 || p.y > H) p.vy *= -1;
      const dx = p.x - mx, dy = p.y - my, d2 = dx * dx + dy * dy;
      if (d2 < 14000) { const d = Math.sqrt(d2) || 1, f = (1 - d / 118) * .9; p.x += dx / d * f; p.y += dy / d * f; }
    }
    bgC.lineWidth = 1;
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i]; bgC.fillStyle = `rgba(${r},${g},${b},${.35 * a})`; bgC.beginPath(); bgC.arc(p.x, p.y, p.r, 0, 6.283); bgC.fill();
      for (let j = i + 1; j < pts.length; j++) { const q = pts[j], dx = p.x - q.x, dy = p.y - q.y, d = dx * dx + dy * dy; if (d < 11000) { bgC.strokeStyle = `rgba(${r},${g},${b},${(1 - d / 11000) * .16 * a})`; bgC.beginPath(); bgC.moveTo(p.x, p.y); bgC.lineTo(q.x, q.y); bgC.stroke(); } }
      const dx = p.x - mx, dy = p.y - my, d = dx * dx + dy * dy;
      if (d < 22000 && FINE) { bgC.strokeStyle = `rgba(${r},${g},${b},${(1 - d / 22000) * .5})`; bgC.beginPath(); bgC.moveTo(p.x, p.y); bgC.lineTo(mx, my); bgC.stroke(); }
    }
  }
  function startBg() { if (prefs.bg && !RM) { bgCv.style.display = ''; if (!bgRaf) bgRaf = requestAnimationFrame(bgTick); } else { bgCv.style.display = 'none'; } }

  // ---------- custom cursor ----------
  const dot = $('#cursorDot'), ring = $('#cursorRing'), ringLbl = ring.firstElementChild;
  let cx = W / 2, cy = H / 2, rx = cx, ry = cy, moved = false, lx = 0, ly = 0, magEl = null, tiltEl = null, hero = null;
  const INTERACT = 'a,button,[data-o],label,summary,.hm-cell,[data-cursor],.pal li,.ring-wrap';
  function setCursorState(t) {
    const txt = t.closest && t.closest('input:not([type=file]):not([type=checkbox]),textarea,select');
    root.classList.toggle('cur-text', !!txt);
    const card = t.closest && t.closest('.card-inner');
    const link = t.closest && t.closest(INTERACT);
    ring.classList.toggle('is-card', !!card && !link);
    ring.classList.toggle('is-link', !!link);
    const lbl = link ? (link.dataset.cursor || '') : card && !link ? 'FLIP' : '';
    ring.classList.toggle('has-label', !!(link && lbl));
    if (ringLbl.textContent !== lbl) ringLbl.textContent = lbl;
  }
  function onMove(e) {
    if (e.pointerType === 'touch') return;
    cx = e.clientX; cy = e.clientY; mx = cx; my = cy;
    if (!moved) { moved = true; rx = cx; ry = cy; if (prefs.cursor && FINE && !RM) root.classList.add('fx-cursor'); }
    root.classList.remove('cur-out');
    dot.style.transform = `translate3d(${cx}px,${cy}px,0)`;
    // sparkle trail
    if (prefs.cursor && FINE && !RM) { const d = Math.hypot(cx - lx, cy - ly); if (d > 16) { lx = cx; ly = cy; spawn({ kind: 'spark', x: cx + rand(-3, 3), y: cy + rand(-3, 3), vx: rand(-.4, .4), vy: rand(-.5, .2), g: .015, drag: .98, s: rand(1.2, 2.6), life: rand(380, 720), age: 0, c: col() }); } }
    if (!FINE || RM) return;
    // magnetic buttons
    const m = e.target.closest && e.target.closest('.primary,#addBtn,#theme,#fxBtn,#palBtn,.streak');
    if (magEl && magEl !== m) { magEl.style.translate = ''; }
    magEl = m;
    if (m) { m.classList.add('mag'); const r = m.getBoundingClientRect(); m.style.translate = `${((cx - r.left - r.width / 2) * .22).toFixed(1)}px ${((cy - r.top - r.height / 2) * .3).toFixed(1)}px`; }
    // tilt + glow
    const t = e.target.closest && e.target.closest('.fx-glow,.fx-tilt');
    if (tiltEl && tiltEl !== t) { tiltEl.style.setProperty('--rx', '0deg'); tiltEl.style.setProperty('--ry', '0deg'); }
    tiltEl = t;
    if (t) {
      const r = t.getBoundingClientRect(), px = (cx - r.left) / r.width, py = (cy - r.top) / r.height, amp = +(t.dataset.tilt || 9);
      t.style.setProperty('--gx', (cx - r.left) + 'px'); t.style.setProperty('--gy', (cy - r.top) + 'px');
      if (t.classList.contains('fx-tilt')) { t.style.setProperty('--rx', ((.5 - py) * amp).toFixed(2) + 'deg'); t.style.setProperty('--ry', ((px - .5) * amp * 1.2).toFixed(2) + 'deg'); }
    }
  }
  addEventListener('pointermove', onMove, { passive: true });
  addEventListener('pointerover', e => { if (e.pointerType !== 'touch') setCursorState(e.target); }, { passive: true });
  document.addEventListener('mouseleave', () => root.classList.add('cur-out'));
  addEventListener('pointerdown', e => {
    ring.classList.add('is-down'); if (!RM) burst(e.clientX, e.clientY, e.pointerType === 'touch' ? 10 : 14);
    const b = e.target.closest && e.target.closest('button'); // ripple
    if (b && !RM) { const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2, el = document.createElement('span'); el.className = 'ripple'; el.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`; b.appendChild(el); setTimeout(() => el.remove(), 650); }
    if (prefs.sound) sound('click');
  }, { passive: true });
  addEventListener('pointerup', () => ring.classList.remove('is-down'), { passive: true });
  (function loop() {
    rx += (cx - rx) * .17; ry += (cy - ry) * .17; ring.style.transform = `translate3d(${rx}px,${ry}px,0)`;
    if (hero && hero.isConnected && FINE) { const r = hero.getBoundingClientRect(), px = Math.max(-1, Math.min(1, ((rx - r.left) / r.width - .5) * 2)), py = Math.max(-1, Math.min(1, ((ry - r.top) / r.height - .5) * 2)); hero.style.setProperty('--px', px.toFixed(3)); hero.style.setProperty('--py', py.toFixed(3)); }
    requestAnimationFrame(loop);
  })();

  // ---------- scroll progress ----------
  const prog = $('#progress');
  const onScroll = () => { const m = document.documentElement.scrollHeight - innerHeight; prog.style.transform = `scaleX(${m > 0 ? Math.min(1, scrollY / m) : 0})`; };
  addEventListener('scroll', onScroll, { passive: true });

  // ---------- nav indicator ----------
  function nav() {
    const on = $('#nav button.on'), ind = $('#navInd'); if (!on || !ind) return;
    ind.style.width = on.offsetWidth + 'px'; ind.style.transform = `translate(${on.offsetLeft}px,${on.offsetTop}px)`; ind.style.height = on.offsetHeight + 'px';
  }
  addEventListener('resize', () => { nav(); resize(); });
  document.fonts && document.fonts.ready.then(nav);

  // ---------- text effects ----------
  const GL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789#%&*';
  function splitNode(node, idx) {
    [...node.childNodes].forEach(n => {
      if (n.nodeType === 3) {
        const frag = document.createDocumentFragment();
        n.textContent.split(/(\s+)/).forEach(tok => {
          if (!tok) return;
          if (/^\s+$/.test(tok)) return frag.appendChild(document.createTextNode(' '));
          const w = document.createElement('span'); w.className = 'w'; w.setAttribute('aria-hidden', 'true');
          [...tok].forEach(ch => { const c = document.createElement('span'); c.className = 'ch'; c.style.setProperty('--ci', idx.i++); c.textContent = ch; w.appendChild(c); });
          frag.appendChild(w);
        });
        n.replaceWith(frag);
      } else if (n.nodeType === 1) splitNode(n, idx);
    });
  }
  function scramble(h) {
    const L = [...h.querySelectorAll('.ch')], orig = L.map(l => l.textContent), t0 = performance.now(), step = Math.min(38, 700 / Math.max(1, L.length));
    (function f(t) {
      let done = true;
      L.forEach((l, i) => { const k = (t - t0 - 120) / step - i; if (k >= 0) { if (l.textContent !== orig[i]) l.textContent = orig[i]; l.classList.remove('scr'); } else { done = false; l.textContent = GL[Math.random() * GL.length | 0]; l.classList.add('scr'); } });
      if (!done && h.isConnected) requestAnimationFrame(f);
    })(t0);
  }
  function heading(h, animate) {
    const txt = h.textContent; h.setAttribute('aria-label', txt); splitNode(h, { i: 0 }); h.classList.add('fx-h');
    if (animate && !RM) scramble(h);
  }
  function countUps(scope) {
    scope.querySelectorAll('.tile b').forEach(b => {
      const m = b.textContent.match(/^(\D*)(\d+)(\D*)$/); if (!m || RM) return; const to = +m[2], t0 = performance.now();
      (function f(t) { const p = Math.min(1, (t - t0) / 1000), e = 1 - Math.pow(1 - p, 3); b.textContent = m[1] + Math.round(to * e) + m[3]; if (p < 1 && b.isConnected) requestAnimationFrame(f); })(t0);
    });
  }

  // ---------- scroll reveal + enhance on every view render ----------
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .06, rootMargin: '0px 0px -30px 0px' });
  const REV = '#app>.sub,#app>.tabs,#app>.search,#app>.tiles>.tile,#app .panel,#app .deck,#app .course>.chead,#app .course>.seg,#app .course>.segtxt,#app .qbox,#app>.hero,#app>.podium,#app .done>*,#app>.row';
  let lastH = '';
  function enhance() {
    const app = $('#app'); if (!app) return;
    const h = app.querySelector('h2'), animate = h && h.textContent !== lastH;
    if (h) { lastH = h.textContent; heading(h, animate); }
    hero = app.querySelector('.hero');
    app.querySelectorAll('.deck,.tile').forEach(el => el.classList.add('fx-glow', 'fx-tilt'));
    app.querySelectorAll('.panel,.hero').forEach(el => el.classList.add('fx-glow'));
    app.querySelectorAll('.scene').forEach(el => { el.classList.add('fx-tilt'); el.dataset.tilt = 4; });
    app.querySelectorAll('.board tr:not(:first-child)').forEach((tr, i) => { tr.classList.add('rowin'); tr.style.setProperty('--i', i); });
    app.querySelectorAll('.bar-r').forEach((r, i) => r.style.setProperty('--i', i));
    app.querySelectorAll('.dot-a').forEach((r, i) => r.style.setProperty('--i', i));
    app.querySelectorAll('.line-a').forEach(l => l.setAttribute('pathLength', '1'));
    if (!RM) {
      let n = 0; app.querySelectorAll(REV).forEach(el => {
        el.classList.add('fx-rev'); const vis = el.getBoundingClientRect().top < innerHeight; el.style.setProperty('--d', vis ? Math.min(n++, 9) * 70 + 'ms' : '0s'); io.observe(el);
      });
    }
    countUps(app); nav(); onScroll();
  }
  new MutationObserver(() => enhance()).observe($('#app'), { childList: true }); // microtask: runs before paint, so no flicker

  // ---------- sound (WebAudio, off by default) ----------
  let ac;
  function tone(f, t0, d, type = 'sine', v = .05) {
    const o = ac.createOscillator(), g = ac.createGain(); o.type = type; o.frequency.value = f; o.connect(g); g.connect(ac.destination);
    g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(v, t0 + .01); g.gain.exponentialRampToValueAtTime(.0001, t0 + d); o.start(t0); o.stop(t0 + d + .02);
  }
  function sound(name) {
    if (!prefs.sound) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === 'suspended') ac.resume(); const t = ac.currentTime;
      if (name === 'click') tone(520, t, .06, 'triangle', .03);
      else if (name === 'flip') { tone(380, t, .07, 'triangle', .04); tone(560, t + .05, .08, 'triangle', .03); }
      else if (name === 'good') { tone(660, t, .12); tone(880, t + .09, .18); }
      else if (name === 'perfect') [523, 659, 784, 1046].forEach((f, i) => tone(f, t + i * .07, .2));
      else if (name === 'bad') { tone(180, t, .22, 'sawtooth', .04); tone(130, t + .1, .25, 'sawtooth', .035); }
      else if (name === 'done') [523, 659, 784, 1046, 1318].forEach((f, i) => tone(f, t + i * .09, .32, 'triangle', .06));
      else if (name === 'bell') [880, 1175, 880, 1175].forEach((f, i) => tone(f, t + i * .22, .4, 'sine', .07));
    } catch {}
  }

  // ---------- feedback helpers used by app.js ----------
  function flash(kind) { if (RM) return; const d = document.createElement('div'); d.className = 'flash ' + kind; document.body.appendChild(d); setTimeout(() => d.remove(), 750); }
  function feedback(g, el) {
    const good = g >= 3; let x = innerWidth / 2, y = innerHeight * .8;
    if (el) { const r = el.getBoundingClientRect(); x = r.left + r.width / 2; y = r.top + r.height / 2; }
    if (good) burst(x, y, g >= 5 ? 34 : 20); flash(good ? 'good' : 'bad'); sound(g === 5 ? 'perfect' : good ? 'good' : 'bad');
  }
  function bump(el) { if (!el) return; el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); }
  const celebrate = () => { confetti(); sound('done'); };

  window.FX = { prefs, save, ACCENTS, RM, FINE, burst, confetti, celebrate, flash, feedback, bump, sound, nav, enhance, applyAccent, refreshColors,
    setBg(v) { prefs.bg = v; save(); startBg(); },
    setCursor(v) { prefs.cursor = v; save(); root.classList.toggle('fx-cursor', v && moved && FINE && !RM); },
    setSound(v) { prefs.sound = v; save(); if (v) sound('good'); },
    setAccent(a) { prefs.accent = a; save(); applyAccent(); },
    setGoal(n) { prefs.goal = n; save(); } };

  refreshColors(); resize(); startBg(); applyAccent();
})();
