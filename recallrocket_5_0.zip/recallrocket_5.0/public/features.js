/* RecallRocket 3.0 · feature layer: dashboard hero, XP levels, goal ring, heatmap,
   command palette, settings, shortcuts help, Pomodoro timer, focus mode.
   Loaded after app.js, so it can call its view functions (showHome, showDecks, ...). */
(() => {
  const q = s => document.querySelector(s);
  const body = document.body;
  const esc2 = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // ---------- levels (XP = the same composite score the leaderboard uses) ----------
  const TITLES = ['Cadet', 'Launch Pad', 'Liftoff', 'Orbit', 'Moon Walker', 'Mars Rover', 'Deep Space', 'Galaxy Pilot'];
  function level(me) {
    const xp = me.totalReviews + me.streak * 10 + me.retentionPoints, lvl = Math.floor(Math.sqrt(xp / 25)) + 1;
    const lo = 25 * (lvl - 1) ** 2, hi = 25 * lvl ** 2;
    return { xp, lvl, title: TITLES[Math.min(lvl - 1, TITLES.length - 1)], pct: Math.round(100 * (xp - lo) / (hi - lo)), next: hi - xp };
  }

  const TIPS = ['Try to answer out loud before you flip. Active recall beats re-reading.',
    'Rate honestly. A low grade today saves you a blank mind on exam day.',
    'Short daily sessions beat one long cram. Keep the streak alive.',
    'Reviews land on day 1, 6, then weeks apart. That is the SM-2 rhythm.',
    'Sleep is part of the algorithm. Review tonight, let your brain file it.'];
  const GOALS = [5, 10, 20, 30], CIRC = 276.46;

  function hero(me, due, today, weakN) {
    const L = level(me), h = new Date().getHours(), greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
    const stars = Array.from({ length: 9 }, (_, i) => `<span class="star" style="left:${(i * 37 + 8) % 92}%;top:${(i * 53 + 10) % 86}%;animation-delay:${(i * .43).toFixed(2)}s"></span>`).join('');
    return `<section class="hero">
      <div class="hero-copy">
        <p class="eyebrow">${greet} · Level ${L.lvl} · ${L.title}</p>
        <h2 class="hero-title">Ready for liftoff, <span class="grad">Commander</span>?</h2>
        <p class="typer" id="typer" aria-live="off"></p>
        <div class="hero-cta"><button class="primary" id="goMixed" data-cursor="GO" ${due ? '' : 'disabled'}>${due ? `Start mixed review · ${due} due` : 'All caught up'}</button>
          ${weakN ? `<button id="goWeak">Practice ${weakN} weak spots</button>` : ''}</div>
        <div class="xp" title="XP = reviews + 10 × streak + retention points"><div class="xp-bar"><i style="width:${L.pct}%"></i></div>
          <small><span><b>${L.xp} XP</b></span><span>${L.next} XP to level ${L.lvl + 1}</span></small></div>
      </div>
      <div class="hero-art" aria-hidden="true">${stars}<div class="orbit"></div>
        <svg class="rocket-big" viewBox="0 0 32 32"><path class="r-body" d="M16 2c5 4 7 10 6 18H10C9 12 11 6 16 2z"/><circle cx="16" cy="12" r="2.6" fill="#fff"/><path d="M10 15l-5 6 5-1zM22 15l5 6-5-1z" fill="#ff5a1f"/><path class="flame" d="M13 22h6l-3 9z"/></svg></div>
      <div class="ring-wrap" id="goal" role="button" tabindex="0" data-cursor="GOAL" data-today="${today}" title="Daily goal: click to change" aria-label="Daily goal progress. Click to change the goal.">
        <svg viewBox="0 0 104 104"><circle class="rt" cx="52" cy="52" r="44"/><circle class="rp" cx="52" cy="52" r="44" style="stroke-dashoffset:${CIRC}"/></svg>
        <div class="rc"><span id="goalTxt"></span><small>today / goal</small></div></div>
    </section>`;
  }

  function typer(el) {
    if (!el) return;
    if (FX.RM) { el.textContent = TIPS[0]; return; }
    let i = Math.floor(Math.random() * TIPS.length), j = 0, del = false;
    (function tick() {
      if (!el.isConnected) return; const t = TIPS[i];
      if (!del) { el.textContent = t.slice(0, ++j); if (j === t.length) { del = true; return setTimeout(tick, 3400); } return setTimeout(tick, 26); }
      el.textContent = t.slice(0, --j); if (j === 0) { del = false; i = (i + 1) % TIPS.length; return setTimeout(tick, 350); } setTimeout(tick, 10);
    })();
  }

  function paintGoal() {
    const g = q('#goal'); if (!g) return; const today = +g.dataset.today, goal = FX.prefs.goal, p = Math.min(1, today / goal);
    q('#goalTxt').textContent = `${today}/${goal}`; g.classList.toggle('ok', today >= goal);
    g.querySelector('.rp').style.strokeDashoffset = (CIRC * (1 - p)).toFixed(2);
  }
  function bindHome({ startMixed, startWeak }) {
    const m = q('#goMixed'), w = q('#goWeak'), g = q('#goal');
    if (m) m.onclick = startMixed; if (w) w.onclick = startWeak;
    if (g) {
      const cycle = () => { FX.setGoal(GOALS[(GOALS.indexOf(FX.prefs.goal) + 1) % GOALS.length] || 10); paintGoal(); const r = g.getBoundingClientRect(); FX.burst(r.left + r.width / 2, r.top + r.height / 2, 10); toast(`Daily goal: ${FX.prefs.goal} cards`); };
      g.onclick = cycle; g.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); cycle(); } };
      setTimeout(paintGoal, 450);
      if (+g.dataset.today >= FX.prefs.goal && !sessionStorage.getItem('rr-goal-' + new Date().toDateString())) { try { sessionStorage.setItem('rr-goal-' + new Date().toDateString(), 1); } catch {} setTimeout(() => FX.celebrate(), 700); }
    }
    typer(q('#typer'));
  }

  function heatmap(h) {
    const first = new Date(h.days[0].date + 'T00:00:00Z').getUTCDay(), last = h.days.length - 1;
    const lv = n => !n ? 0 : n <= h.best * .25 ? 1 : n <= h.best * .5 ? 2 : n <= h.best * .75 ? 3 : 4;
    const cells = Array(first).fill('<i class="hm-cell e"></i>').concat(h.days.map((d, i) =>
      `<i class="hm-cell${i === last ? ' td' : ''}" data-l="${lv(d.n)}" style="--c:${Math.floor((i + first) / 7)}" title="${d.date}: ${d.n} review${d.n === 1 ? '' : 's'}"></i>`));
    return `<div class="hm-sum"><span><b>${h.total}</b> reviews</span><span><b>${h.active}</b> active days</span><span>best day <b>${h.best}</b></span></div><div class="hm" role="img" aria-label="Study heatmap of the last 13 weeks">${cells.join('')}</div>`;
  }

  window.RRX = { level, hero, heatmap, bindHome, typer };

  // ---------- overlays ----------
  let closer = null;
  function overlay(html, cls = 'ovl-back') {
    close(); const d = document.createElement('div'); d.className = cls; d.innerHTML = html; body.appendChild(d); body.classList.add('ovl');
    d.addEventListener('mousedown', e => { if (e.target === d) close(); }); closer = () => { d.remove(); body.classList.remove('ovl'); closer = null; };
    return d;
  }
  function close() { if (closer) closer(); }

  // ---------- focus mode ----------
  const tag = document.createElement('div'); tag.className = 'focus-tag'; tag.textContent = 'Focus mode · press F or Esc to exit'; body.appendChild(tag);
  function focusMode(v = !body.classList.contains('focus')) { body.classList.toggle('focus', v); toast(v ? 'Focus mode on. Press F or Esc to exit.' : 'Focus mode off'); }

  // ---------- Pomodoro ----------
  const pomo = document.createElement('div'); pomo.className = 'pomo'; pomo.id = 'pomo';
  pomo.innerHTML = '<span class="lbl">Focus</span><span class="t" id="pomoT">25:00</span><button id="pomoGo">Start</button><button id="pomoLen" title="Change length">25m</button><button id="pomoRst" aria-label="Reset timer">Reset</button>';
  body.appendChild(pomo);
  const LENS = [15, 25, 50]; let len = 25, left = 25 * 60, end = 0, timer = 0;
  const fmt = s => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  function pShow() { q('#pomoT').textContent = fmt(left); q('#pomoGo').textContent = timer ? 'Pause' : 'Start'; pomo.classList.toggle('run', !!timer); document.title = timer ? `(${fmt(left)}) RecallRocket` : 'RecallRocket · Launch your memory'; }
  function pTick() { left = Math.max(0, Math.round((end - Date.now()) / 1000)); if (!left) { clearInterval(timer); timer = 0; left = len * 60; FX.sound('bell'); FX.confetti(90); toast('Focus session complete! Take a 5 minute break.'); } pShow(); }
  const pToggle = () => { if (timer) { clearInterval(timer); timer = 0; } else { end = Date.now() + left * 1000; timer = setInterval(pTick, 250); toast(`Timer started: ${fmt(left)}`); } pShow(); };
  q('#pomoGo').onclick = pToggle;
  q('#pomoRst').onclick = () => { clearInterval(timer); timer = 0; left = len * 60; pShow(); };
  q('#pomoLen').onclick = () => { if (timer) return toast('Pause the timer to change its length'); len = LENS[(LENS.indexOf(len) + 1) % LENS.length]; left = len * 60; q('#pomoLen').textContent = len + 'm'; pShow(); };

  // ---------- command palette ----------
  const fuzzy = (needle, hay) => {
    if (!needle) return { score: 0, html: esc2(hay) };
    const n = needle.toLowerCase(), h = hay.toLowerCase(), at = h.indexOf(n);
    if (at >= 0) return { score: at, html: esc2(hay.slice(0, at)) + '<mark>' + esc2(hay.slice(at, at + n.length)) + '</mark>' + esc2(hay.slice(at + n.length)) };
    let j = 0, out = '', gaps = 0; for (let i = 0; i < hay.length; i++) { if (j < n.length && h[i] === n[j]) { out += '<mark>' + esc2(hay[i]) + '</mark>'; j++; } else { out += esc2(hay[i]); gaps++; } }
    return j === n.length ? { score: 50 + gaps, html: out } : null;
  };
  async function palette() {
    let decks = []; try { decks = (await api('/api/courses')).flatMap(c => c.decks).filter(d => d.due); } catch {}
    const on = v => v ? 'on' : 'off';
    const items = [
      ['Go to Dashboard', 'Navigate', () => showHome()], ['Go to Courses', 'Navigate', () => showDecks()], ['Go to Tests', 'Navigate', () => showTests()],
      ['Go to Leaderboard', 'Navigate', () => showBoard()], ['Go to Forgetting curve', 'Navigate', () => showCurve()],
      ['Start mixed review (all due cards)', 'Study', () => startMixed()], ['Practice weak spots', 'Study', () => startWeak()],
      ...decks.map(d => [`Review ${d.name}`, `${d.due} due`, () => startStudy(d.id, d)]),
      ['New card or deck', 'Create', () => openModal()],
      ['Toggle dark mode', 'Appearance', () => q('#theme').click()], ['Toggle focus mode', 'Appearance', () => focusMode()],
      ...Object.keys(FX.ACCENTS).map(a => [`Accent colour: ${a}`, 'Appearance', () => FX.setAccent(a)]),
      [`Sound effects (${on(FX.prefs.sound)})`, 'Settings', () => { FX.setSound(!FX.prefs.sound); toast('Sound ' + on(FX.prefs.sound)); }],
      [`Cursor effects (${on(FX.prefs.cursor)})`, 'Settings', () => { FX.setCursor(!FX.prefs.cursor); toast('Cursor effects ' + on(FX.prefs.cursor)); }],
      [`Animated background (${on(FX.prefs.bg)})`, 'Settings', () => { FX.setBg(!FX.prefs.bg); toast('Background ' + on(FX.prefs.bg)); }],
      ['Start or pause Pomodoro timer', 'Tools', pToggle], ['Keyboard shortcuts', 'Help', help]];
    const d = overlay(`<div class="pal" role="dialog" aria-label="Command palette"><input id="palIn" placeholder="Type a command or deck name…" autocomplete="off" aria-label="Search commands"><ul id="palList" role="listbox"></ul>
      <div class="foot"><span><kbd>↑</kbd> <kbd>↓</kbd> move</span><span><kbd>Enter</kbd> run</span><span><kbd>Esc</kbd> close</span></div></div>`);
    const inp = d.querySelector('#palIn'), ul = d.querySelector('#palList'); let sel = 0, shown = [];
    const draw = () => {
      shown = items.map(it => ({ it, m: fuzzy(inp.value.trim(), it[0]) })).filter(x => x.m).sort((a, b) => a.m.score - b.m.score).slice(0, 9);
      sel = Math.min(sel, Math.max(0, shown.length - 1));
      ul.innerHTML = shown.length ? shown.map((x, i) => `<li role="option" data-i="${i}" class="${i === sel ? 'sel' : ''}"><span>${x.m.html}</span><small>${esc2(x.it[1])}</small></li>`).join('') : '<li><span>No matches</span></li>';
    };
    const run = i => { const x = shown[i]; if (!x) return; close(); x.it[2](); };
    inp.oninput = () => { sel = 0; draw(); };
    inp.onkeydown = e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); sel = (sel + 1) % shown.length; draw(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); sel = (sel - 1 + shown.length) % shown.length; draw(); }
      else if (e.key === 'Enter') { e.preventDefault(); run(sel); } else if (e.key === 'Escape') { e.stopPropagation(); close(); }
    };
    ul.onclick = e => { const li = e.target.closest('li[data-i]'); if (li) run(+li.dataset.i); };
    ul.onmousemove = e => { const li = e.target.closest('li[data-i]'); if (li && +li.dataset.i !== sel) { sel = +li.dataset.i; ul.querySelectorAll('li').forEach(l => l.classList.toggle('sel', l === li)); } };
    draw(); inp.focus();
  }

  // ---------- shortcuts help ----------
  function help() {
    const rows = [['Space', 'Flip the card'], ['0 – 5', 'Rate recall (SM-2 grade)'], ['1 – 4', 'Pick a test answer'], ['Ctrl / ⌘ + K  or  /', 'Command palette'],
      ['F', 'Focus mode (hides the header)'], ['D', 'Toggle dark mode'], ['P', 'Start / pause Pomodoro'], ['?', 'This help'], ['Esc', 'Close or leave focus mode']];
    overlay(`<div class="helpbox" role="dialog" aria-label="Keyboard shortcuts"><h2 style="font-size:1.5rem">Keyboard shortcuts</h2>
      <dl>${rows.map(([k, v]) => `<dt>${k.split(/\s+/).map(x => /^[+or]+$/.test(x) ? x : `<kbd>${esc2(x)}</kbd>`).join(' ')}</dt><dd>${v}</dd>`).join('')}</dl></div>`);
  }

  // ---------- settings panel ----------
  function settings() {
    if (q('.fxpanel')) return closePanel();
    const p = document.createElement('div'); p.className = 'fxpanel'; p.setAttribute('role', 'dialog'); p.setAttribute('aria-label', 'Appearance and effects');
    const dark = document.documentElement.dataset.theme === 'dark';
    p.innerHTML = `<h4>Accent colour</h4><div class="swatches">${Object.entries(FX.ACCENTS).map(([k, v]) => `<button class="sw ${FX.prefs.accent === k ? 'on' : ''}" data-a="${k}" style="--c:${v[dark ? 1 : 0]}" aria-label="${k}" title="${k}"></button>`).join('')}</div>
      <h4>Effects</h4>
      <label class="tog">Cursor glow and trail<input type="checkbox" data-t="cursor" ${FX.prefs.cursor ? 'checked' : ''}></label>
      <label class="tog">Animated background<input type="checkbox" data-t="bg" ${FX.prefs.bg ? 'checked' : ''}></label>
      <label class="tog">Sound effects<input type="checkbox" data-t="sound" ${FX.prefs.sound ? 'checked' : ''}></label>
      <label class="tog">Focus mode<input type="checkbox" data-t="focus" ${body.classList.contains('focus') ? 'checked' : ''}></label>`;
    body.appendChild(p);
    p.onclick = e => { const a = e.target.closest('[data-a]'); if (a) { FX.setAccent(a.dataset.a); p.querySelectorAll('.sw').forEach(s => s.classList.toggle('on', s === a)); } };
    p.onchange = e => { const t = e.target.dataset.t, v = e.target.checked; ({ cursor: FX.setCursor, bg: FX.setBg, sound: FX.setSound, focus: () => { closePanel(); focusMode(v); } })[t](v); };
    setTimeout(() => document.addEventListener('mousedown', outside), 0);
  }
  const outside = e => { if (!e.target.closest('.fxpanel') && !e.target.closest('#fxBtn')) closePanel(); };
  function closePanel() { const p = q('.fxpanel'); if (p) p.remove(); document.removeEventListener('mousedown', outside); }
  q('#fxBtn').onclick = settings; q('#palBtn').onclick = palette;

  // ---------- global shortcuts ----------
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); return palette(); }
    if (e.key === 'Escape') { if (closer) return close(); if (q('.fxpanel')) return closePanel(); if (body.classList.contains('focus')) return focusMode(false); }
    if (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.ctrlKey || e.metaKey || e.altKey || body.classList.contains('ovl') || !q('#modal').classList.contains('hidden')) return;
    const k = e.key.toLowerCase();
    if (k === '/') { e.preventDefault(); palette(); } else if (e.key === '?') help();
    else if (k === 'f') focusMode(); else if (k === 'd') q('#theme').click(); else if (k === 'p') pToggle();
  });
  FX.nav(); pShow();
})();
