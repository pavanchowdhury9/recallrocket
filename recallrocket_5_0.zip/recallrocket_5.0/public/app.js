const $ = s => document.querySelector(s), app = $('#app');
const LABELS = ['Blackout', 'Wrong', 'Hard miss', 'Hard', 'Good', 'Perfect'];
const BADGES = { 3: '3-day spark', 7: '7-day streak', 30: '30-day legend' };
let S = { me: null, queue: [], i: 0, flipped: false, deck: null, startRank: 0, startStreak: 0, count: 0, streakUp: false, view: 'decks' };

/** Fetch JSON from the server. GET by default; passing a body makes it a POST unless `method` says otherwise. */
const api = async (url, body, method = body === undefined ? 'GET' : 'POST') => {
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 20000);
  let r;
  try {
    r = await fetch(url, { method, signal: ctl.signal, headers: body === undefined ? {} : { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch (e) {
    throw new Error(e.name === 'AbortError' ? 'The server took too long to respond. Please try again.' : 'Cannot reach the server. Check that it is running.');
  } finally { clearTimeout(timer); }
  let j = null; try { j = await r.json(); } catch { /* non-JSON body */ }
  if (!r.ok) throw new Error((j && j.error) || (r.status === 429 ? 'Too many requests. Please wait a moment.' : `Request failed (${r.status})`));
  return j;
};
/** Escape text for safe use in HTML content and quoted attributes. */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const md = s => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/\*([^*]+)\*/g, '<i>$1</i>').replace(/\n/g, '<br>');
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2400); }
function countUp(el, to, ms = 900) {
  const t0 = performance.now(); (function f(t) { const p = Math.min(1, (t - t0) / ms); el.textContent = Math.round(to * p); if (p < 1) requestAnimationFrame(f); })(t0);
}
async function refreshMe() { S.me = await api('/api/me'); $('#streakNum').textContent = S.me.streak; }
const speak = txt => speechSynthesis.speak(new SpeechSynthesisUtterance(txt.replace(/[`*]/g, '')));
const cardHTML = (c, id = 'ci') => `<div class="scene"><div class="card-inner" id="${id}">
  <div class="face front"><button class="speak" data-say="${esc(c.front).replace(/"/g, '&quot;')}" aria-label="Read aloud">Listen</button>${md(c.front)}</div>
  <div class="face back"><button class="speak" data-say="${esc(c.back).replace(/"/g, '&quot;')}" aria-label="Read aloud">Listen</button>${md(c.back)}</div></div></div>`;
function bindCard(id = 'ci', onFlip) {
  const ci = document.getElementById(id);
  ci.onclick = e => { if (e.target.dataset.say) return speak(e.target.dataset.say); flip(ci, onFlip); };
}
function flip(ci, cb) { FX.sound('flip'); ci.classList.toggle('flipped'); if (cb) cb(ci.classList.contains('flipped')); }

// ---- Views ----
const deckCard = d => `<div class="deck"><h3>${esc(d.name)}</h3><div class="due">${d.due}</div><small>due today · ${d.total} cards</small>
  <button class="primary" data-study="${d.id}" ${d.due ? '' : 'disabled'}>${d.due ? 'Start review' : 'All caught up'}</button>
  <div class="tools"><button type="button" class="linkbtn" data-manage="${d.id}">Manage cards</button><a href="/api/decks/${d.id}/export" download>Export CSV</a><label>Import CSV / Anki<input type="file" accept=".csv,.txt,.tsv" hidden data-imp="${d.id}"></label></div></div>`;
const seg = c => `<div class="seg" title="Mastered / learning / new"><i class="m" style="width:${c.mature / (c.total || 1) * 100}%"></i><i class="l" style="width:${c.learning / (c.total || 1) * 100}%"></i></div>
  <div class="segtxt">${c.mature} mastered · ${c.learning} learning · ${c.new} new</div>`;
function bindDecks(all) {
  app.querySelectorAll('[data-imp]').forEach(i => i.onchange = async () => {
    const f = i.files[0]; if (!f) return;
    try { const r = await api(`/api/decks/${i.dataset.imp}/import`, { csv: await f.text() }); toast(`Imported ${r.added} cards. They are due today.`); showDecks(); }
    catch (e) { toast(e.message); }
  });
  app.querySelectorAll('[data-manage]').forEach(b => b.onclick = () => openManager(+b.dataset.manage).catch(e => toast(e.message)));
  app.querySelectorAll('[data-study]').forEach(b => b.onclick = () => startStudy(+b.dataset.study, all.find(d => d.id === +b.dataset.study)));
}
async function showDecks() {
  S.view = 'decks'; setNav('decks');
  const courses = await api('/api/courses'), all = courses.flatMap(c => c.decks), due = all.reduce((a, d) => a + d.due, 0);
  app.innerHTML = `<h2>Courses</h2><p class="sub"><mark class="hl">${due} card${due === 1 ? '' : 's'} due today</mark>. Mastered means the next review is 6+ days away.</p>
    <input class="search" id="q" type="search" placeholder="Search decks…" aria-label="Search decks" autocomplete="off"><p class="sub hidden" id="noHit">No deck matches that search.</p>` +
    courses.map(c => `<section class="course"><div class="chead"><h3>${esc(c.name)}</h3><small>${esc(c.description || '')}</small></div>${seg(c)}
    <div class="grid">${c.decks.map(deckCard).join('')}</div></section>`).join('');
  bindDecks(all); bindSearch();
}
function bindSearch() {
  const q = $('#q'); if (!q) return;
  q.oninput = () => {
    const v = q.value.trim().toLowerCase(); let hits = 0;
    app.querySelectorAll('.course').forEach(c => {
      let any = false;
      c.querySelectorAll('.deck').forEach(d => {
        const h = d.querySelector('h3'), n = h.dataset.n || (h.dataset.n = h.textContent), ok = !v || n.toLowerCase().includes(v);
        d.classList.toggle('hidden', !ok); if (ok) { any = true; hits++; }
        // highlight the matching letters (split on the raw text, then escape each piece)
        h.innerHTML = v && ok ? n.split(new RegExp('(' + v.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'i')).map((x, i) => i % 2 ? `<mark class="hl hl-now">${esc(x)}</mark>` : esc(x)).join('') : esc(n);
      });
      c.classList.toggle('hidden', !any);
    });
    $('#noHit').classList.toggle('hidden', hits > 0);
  };
}
async function startStudy(id, deck) { begin(await api(`/api/decks/${id}/due`), deck); }
const startMixed = async () => begin(await api('/api/due'), { name: 'Mixed review' });
const startWeak = async () => begin(await api('/api/weak'), { name: 'Weak spots' });
function begin(queue, deck) {
  if (!queue.length) return toast('Nothing to review right now. Nice work!');
  S.queue = queue; S.i = 0; S.deck = deck; S.count = 0; S.streakUp = false;
  S.startRank = S.me.rank; S.startStreak = S.me.streak; S.view = 'study'; renderCard();
}
function renderCard() {
  if (S.i >= S.queue.length) return finish();
  const c = S.queue[S.i]; S.flipped = false;
  app.innerHTML = `<h2>${esc(S.deck.name)}</h2><p class="sub">Card ${S.i + 1} of ${S.queue.length}${c.deckName ? `<span class="chip">${esc(c.deckName)}</span>` : ''}${c.misses ? `<span class="chip">missed ${c.misses}×</span>` : ''}</p>
  <div class="bar"><i style="width:${S.i / S.queue.length * 100}%"></i></div>${cardHTML(c)}
  <p class="hint" id="hint">Click the card or press <kbd>Space</kbd> to flip · <kbd>F</kbd> focus mode</p>
  <div class="rate off" id="rate">${LABELS.map((l, g) => `<button data-g="${g}">${g}<span>${l}</span></button>`).join('')}</div>`;
  bindCard('ci', f => { S.flipped = f; $('#rate').classList.toggle('off', !f); $('#hint').textContent = f ? 'Rate your recall (0–5, or keys 0–5)' : 'Click the card or press Space to flip'; });
  document.querySelectorAll('#rate button').forEach(b => b.onclick = () => rate(+b.dataset.g));
}
let busy = false;
async function rate(g) {
  if (!S.flipped || busy) return; busy = true;
  try {
    const r = await api('/api/review', { cardId: S.queue[S.i].id, grade: g });
    S.count++; if (r.streakChanged) S.streakUp = true; S.me = { ...r.user, rank: r.rank };
    FX.feedback(g, document.querySelector(`#rate [data-g="${g}"]`));
    $('#streakNum').textContent = r.user.streak; if (r.streakChanged) FX.bump($('#streakNum'));
    toast(g >= 3 ? `Next review in ${r.interval} day${r.interval === 1 ? '' : 's'} (${r.nextReviewDate})` : 'Missed. Back tomorrow (1 day)');
    S.i++; renderCard();
  } catch (e) { toast(e.message); } finally { busy = false; }
}
function finish() {
  const m = S.me, badge = S.streakUp && BADGES[m.streak];
  app.innerHTML = `<div class="done">${badge ? `<div class="badge">${m.streak}-day streak</div><h2>${badge} unlocked</h2>` : '<div class="badge">Done</div><h2>Session complete</h2>'}
  <div class="big" id="cnt">0</div><p class="sub">${S.count} cards reviewed · streak ${S.startStreak} to ${m.streak} days</p>
  <p class="sub">Leaderboard rank: <b>#${S.startRank}</b> to <b>#${m.rank}</b></p>
  <button class="primary" id="b1">View leaderboard</button> <button id="b2">Back to decks</button></div>`;
  countUp($('#cnt'), m.streak); FX.celebrate(); $('#b1').onclick = showBoard; $('#b2').onclick = showDecks; S.view = 'done';
}
const hue = n => [...n].reduce((a, c) => a * 31 + c.charCodeAt(0), 7) % 360, ini = n => n.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();
async function showBoard(by = 'score') {
  if (typeof by !== 'string') by = 'score';
  S.view = 'board'; setNav('board');
  const rows = await api('/api/leaderboard?by=' + by);
  const tabs = [['score', 'Overall'], ['reviews', 'Cards reviewed'], ['streak', 'Streak'], ['retention', 'Retention']];
  const val = r => by === 'streak' ? r.streak + 'd' : r[by], pod = [1, 0, 2].map(i => rows[i] && `<div class="pod p${i + 1}"><div class="av" style="--h:${hue(rows[i].name)}">${ini(rows[i].name)}</div><b>${esc(rows[i].name)}</b><small>${val(rows[i])}</small><div class="step"><span>${i + 1}</span></div></div>`).join('');
  app.innerHTML = `<h2>Campus leaderboard</h2><p class="sub"><mark class="hl">Overall = reviews + 10 × streak + retention points</mark></p>
  <div class="tabs">${tabs.map(([k, l]) => `<button data-by="${k}" class="${k === by ? 'on' : ''}">${l}</button>`).join('')}</div>
  <div class="podium">${pod}</div>
  <table class="board"><tr><th>#</th><th>Student</th><th>Reviews</th><th>Streak</th><th>Retention</th><th>Score</th></tr>
  ${rows.map(r => `<tr class="${r.isMe ? 'me' : ''}"><td>${r.rank}</td><td><span class="av sm" style="--h:${hue(r.name)}">${ini(r.name)}</span>${esc(r.name)}</td><td>${r.reviews}</td><td>${r.streak} days</td><td>${r.retention}</td><td>${r.score}</td></tr>`).join('')}</table>`;
  app.querySelectorAll('[data-by]').forEach(b => b.onclick = () => showBoard(b.dataset.by));
}

// ---- Ebbinghaus forgetting curve ----
function loadChart() {
  return new Promise((ok, no) => { if (window.Chart) return ok();
    const s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js'; s.onload = ok; s.onerror = no; document.head.appendChild(s); });
}
async function showCurve() {
  S.view = 'curve'; setNav('curve');
  app.innerHTML = `<h2>Forgetting curve</h2><p class="sub">Retention R = e<sup>−t/S</sup>. Without review, about 70% is gone after 2 days. Each review resets the curve and makes it flatter (SM-2 reviews on days 0, 1, 7, 23).</p><div class="chartbox"><canvas id="cv"></canvas></div>`;
  try { await loadChart(); } catch { return app.insertAdjacentHTML('beforeend', '<p class="sub">Chart.js could not load. Check your internet connection.</p>'); }
  const days = Array.from({ length: 31 }, (_, i) => i), reviews = [0, 1, 7, 23], S0 = 1.66;
  const plain = days.map(t => +(100 * Math.exp(-t / S0)).toFixed(1));
  const spaced = days.map(t => { const k = reviews.filter(r => r <= t).length - 1; return +(100 * Math.exp(-(t - reviews[k]) / (S0 * 2.5 ** k))).toFixed(1); });
  const marks = days.map(t => reviews.includes(t) ? 100 : null);
  const dark = document.documentElement.dataset.theme === 'dark', txt = dark ? '#eaedff' : '#141b3a';
  new Chart($('#cv'), { type: 'line', data: { labels: days, datasets: [
    { label: 'No review (Ebbinghaus)', data: plain, borderColor: '#d6334a', tension: .3, pointRadius: 0 },
    { label: 'With spaced reviews', data: spaced, borderColor: '#4338ff', tension: .3, pointRadius: 0, borderWidth: 3 },
    { label: 'Review checkpoint', data: marks, borderColor: '#ff5a1f', backgroundColor: '#ff5a1f', showLine: false, pointRadius: 7 }] },
    options: { responsive: true, maintainAspectRatio: false, color: txt, scales: {
      x: { title: { display: true, text: 'Days since first study', color: txt }, ticks: { color: txt } },
      y: { min: 0, max: 100, title: { display: true, text: 'Retention (%)', color: txt }, ticks: { color: txt } } } } });
}

function setNav(v) { document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.view === v)); FX.nav(); }

// ---- Dashboard ----
function perfChart(days) {
  const W = 700, H = 250, L = 36, R = 36, T = 14, B = 28, iw = W - L - R, ih = H - T - B, step = iw / days.length;
  const max = Math.max(5, Math.ceil(Math.max(...days.map(d => d.reviews)) / 5) * 5), y = v => T + (1 - v / max) * ih, ya = v => T + (1 - v / 100) * ih;
  const pts = days.map((d, i) => d.accuracy == null ? null : [L + step * (i + .5), ya(d.accuracy)]).filter(Boolean);
  return `<svg class="svgc" viewBox="0 0 ${W} ${H}" role="img" aria-label="Reviews per day and accuracy, last 14 days">
  ${[0, .5, 1].map(f => `<line class="grid" x1="${L}" x2="${W - R}" y1="${T + ih * f}" y2="${T + ih * f}"/>`).join('')}
  <text x="${L - 6}" y="${T + 4}" text-anchor="end">${max}</text><text x="${L - 6}" y="${T + ih + 4}" text-anchor="end">0</text>
  <text x="${W - R + 6}" y="${T + 4}">100%</text><text x="${W - R + 6}" y="${T + ih + 4}">0%</text>
  ${days.map((d, i) => `<rect class="bar-r" x="${L + step * i + step * .2}" y="${y(d.reviews)}" width="${step * .6}" height="${T + ih - y(d.reviews)}" rx="3"><title>${d.date}: ${d.reviews} reviews</title></rect>
    ${i % 2 === 0 ? `<text x="${L + step * (i + .5)}" y="${H - 8}" text-anchor="middle">${d.date.slice(8)}</text>` : ''}`).join('')}
  <polyline class="line-a" points="${pts.map(p => p.join(',')).join(' ')}"/>${pts.map(p => `<circle class="dot-a" cx="${p[0]}" cy="${p[1]}" r="3.5"/>`).join('')}</svg>
  <div class="legend"><span><i style="background:var(--accent)"></i>Cards reviewed</span><span><i style="background:var(--flame)"></i>Accuracy (grade 3+)</span></div>`;
}
const testRow = t => `<div class="trow"><div><b>${esc(t.title)}</b><small>${esc(t.course)} · due ${t.due}</small></div>
  <span class="pill ${t.status}">${t.status === 'done' ? `${t.score}/${t.total}` : t.status === 'overdue' ? 'Overdue' : 'Pending'}</span>
  <button class="${t.status === 'done' ? '' : 'primary'}" data-test="${t.id}">${t.status === 'done' ? 'Retake' : 'Start'}</button></div>`;
const bindTests = () => app.querySelectorAll('[data-test]').forEach(b => b.onclick = () => startTest(+b.dataset.test));
async function showHome() {
  S.view = 'home'; setNav('home');
  const [me, courses, tests, perf, heat, weak] = await Promise.all([api('/api/me'), api('/api/courses'), api('/api/assignments'), api('/api/performance'), api('/api/heatmap'), api('/api/weak')]);
  S.me = me; $('#streakNum').textContent = me.streak;
  const due = courses.reduce((a, c) => a + c.due, 0), todo = tests.filter(t => t.status !== 'done');
  const today = perf.days[perf.days.length - 1].reviews;
  app.innerHTML = `${RRX.hero(me, due, today, weak.length)}
  <div class="tiles"><div class="tile"><b>${due}</b><small>cards due today</small></div><div class="tile"><b>${me.streak}</b><small>day streak</small></div>
  <div class="tile"><b>#${me.rank}</b><small>campus rank</small></div><div class="tile"><b>${perf.accuracy}%</b><small>recall accuracy</small></div>
  <div class="tile"><b>${perf.avgTest == null ? '–' : perf.avgTest + '%'}</b><small>average test score</small></div></div>
  <div class="panel"><h3>Performance, last 14 days</h3>${perfChart(perf.days)}</div>
  <div class="panel"><h3>Study activity, last 13 weeks</h3>${RRX.heatmap(heat)}</div>
  <div class="cols"><div class="panel"><h3>Test scores</h3>${perf.tests.length ? perf.tests.map(x => `<div class="tbar"><span>${esc(x.title)}</span><div class="track"><i style="width:${x.pct}%"></i></div><b>${x.pct}%</b></div>`).join('') : '<p class="sub">No tests taken yet.</p>'}</div>
  <div class="panel"><h3>Upcoming tests</h3>${todo.length ? todo.map(testRow).join('') : '<p class="sub">Nothing pending. Nice work.</p>'}</div></div>
  <div class="panel"><h3>Course progress</h3>${courses.map(c => `<b>${esc(c.name)}</b>${seg(c)}`).join('')}</div>`;
  bindTests(); RRX.bindHome({ startMixed, startWeak });
}

// ---- Tests (assignments) ----
async function showTests() {
  S.view = 'tests'; setNav('tests');
  const tests = await api('/api/assignments');
  app.innerHTML = `<h2>Tests</h2><p class="sub">Multiple-choice tests built from your course decks. Flip each card (Space), then answer with keys 1–4.</p>
  <div class="panel">${tests.map(testRow).join('')}</div>`;
  bindTests();
}
async function startTest(id) {
  const r = await api(`/api/assignments/${id}/start`, {});
  S.test = { a: r.assignment, qs: r.questions, i: 0, ans: [] }; S.view = 'test'; renderQ();
}
function renderQ() {
  const T = S.test, q = T.qs[T.i];
  if (!q) return submitTest();
  app.innerHTML = `<h2>${esc(T.a.title)}</h2><p class="sub">Question ${T.i + 1} of ${T.qs.length}</p><div class="bar"><i style="width:${T.i / T.qs.length * 100}%"></i></div>
  <div class="scene"><div class="card-inner tq" id="tq">
    <div class="face front">${md(q.front)}<p class="hint">Click the card or press <kbd>Space</kbd> to see the options</p></div>
    <div class="face back opts-face">${q.options.map((o, i) => `<button data-o="${i}"><b>${i + 1}</b><span>${md(o)}</span></button>`).join('')}</div></div></div>
  <p class="hint">Flip, then pick an answer (click or keys 1–4)</p>`;
  const tq = $('#tq');
  tq.onclick = e => { const b = e.target.closest('[data-o]'); if (b) pick(+b.dataset.o); else tq.classList.toggle('flipped'); };
}
function pick(i) {
  const T = S.test, q = T.qs[T.i]; if (!q || i >= q.options.length || !$('#tq').classList.contains('flipped')) return;
  T.ans.push({ cardId: q.cardId, choice: q.options[i] }); T.i++; renderQ();
}
async function submitTest() {
  try {
    const r = await api(`/api/assignments/${S.test.a.id}/submit`, { answers: S.test.ans }); S.view = 'result';
    app.innerHTML = `<div class="done"><div class="badge">${r.score / r.total >= .8 ? 'Great score' : 'Test complete'}</div><h2>${esc(S.test.a.title)}</h2><div class="big">${r.score}/${r.total}</div>
    <p class="sub">${Math.round(100 * r.score / r.total)}% correct</p></div><div class="panel">${r.review.map(x => `<div class="rv"><div>${md(x.front)}</div>
    ${x.ok ? `<div class="ok">Correct: ${md(x.correct)}</div>` : `<div class="no">Your answer: ${md(x.chosen)}</div><div class="ok">Correct answer: ${md(x.correct)}</div>`}</div>`).join('')}</div>
    <div class="row" style="justify-content:center"><button id="r1">Back to tests</button><button class="primary" id="r2">Dashboard</button></div>`;
    $('#r1').onclick = showTests; $('#r2').onclick = showHome; if (r.score / r.total >= .8) FX.celebrate(); else FX.sound('good');
  } catch (e) { toast(e.message); }
}

// ---- Modal: new deck / card with live preview ----
async function openModal() {
  const decks = await api('/api/decks'), m = $('#modal');
  m.classList.remove('hidden');
  m.innerHTML = `<div class="sheet" role="dialog" aria-label="Create"><h2 style="font-size:1.4rem">New card</h2>
  <label>Deck</label><select id="mDeck">${decks.map(d => `<option value="${d.id}">${esc(d.name)}</option>`).join('')}</select>
  <label>Or create a deck</label><input id="mNew" placeholder="e.g. GRE Vocab">
  <label>Front (supports **bold**, *italic*, \`code\`)</label><textarea id="mF" rows="2"></textarea>
  <label>Back</label><textarea id="mB" rows="2"></textarea>
  <p class="hint">Live preview (click to flip)</p><div id="prev"></div>
  <div class="row"><button id="mX">Cancel</button><button class="primary" id="mS">Save card</button></div></div>`;
  const draw = () => { $('#prev').innerHTML = cardHTML({ front: $('#mF').value || 'Question…', back: $('#mB').value || 'Answer…' }, 'pv'); bindCard('pv'); };
  $('#mF').oninput = $('#mB').oninput = draw; draw();
  const close = () => m.classList.add('hidden');
  $('#mX').onclick = close; m.onclick = e => { if (e.target === m) close(); };
  $('#mS').onclick = async () => {
    try {
      let deckId = +$('#mDeck').value; const nm = $('#mNew').value.trim();
      if (nm) deckId = (await api('/api/decks', { name: nm })).id;
      await api('/api/cards', { deckId, front: $('#mF').value, back: $('#mB').value });
      close(); toast('Card saved. It is due today.'); showDecks();
    } catch (e) { toast(e.message); }
  };
  $('#mF').focus();
}

// ---- Manage cards: edit or delete cards, delete the deck ----
async function openManager(deckId) {
  const m = $('#modal'), deck = (await api('/api/decks')).find(d => d.id === deckId), cards = await api(`/api/decks/${deckId}/cards`);
  if (!deck) throw new Error('Deck not found');
  m.classList.remove('hidden');
  m.innerHTML = `<div class="sheet mgr" role="dialog" aria-label="Manage cards"><h2 style="font-size:1.4rem">${esc(deck.name)}</h2>
    <p class="hint" id="mgCount">${cards.length} card${cards.length === 1 ? '' : 's'}. Editing text keeps your review schedule.</p>
    <div class="mgr-list">${cards.map(c => `<div class="mgr-row" data-id="${c.id}">
      <textarea rows="2" maxlength="2000" aria-label="Front" data-f="front">${esc(c.front)}</textarea>
      <textarea rows="2" maxlength="2000" aria-label="Back" data-f="back">${esc(c.back)}</textarea>
      <div class="mgr-act"><button class="primary" data-save>Save</button><button data-del>Delete</button></div></div>`).join('') || '<p class="hint">No cards yet. Use “+ New” to add some.</p>'}</div>
    <div class="row"><button id="mgDeck">Delete deck</button><button class="primary" id="mgX">Done</button></div></div>`;
  const close = () => { m.classList.add('hidden'); if (S.view === 'decks') showDecks(); };
  $('#mgX').onclick = close;
  m.onclick = async e => {
    if (e.target === m) return close();
    const row = e.target.closest('.mgr-row'), t = e.target;
    try {
      if (t.id === 'mgDeck' && confirm(`Delete the deck “${deck.name}” and all its cards? This cannot be undone.`)) { await api(`/api/decks/${deckId}`, undefined, 'DELETE'); toast('Deck deleted.'); close(); }
      else if (row && t.matches('[data-save]')) { const [f, b] = row.querySelectorAll('textarea'); await api(`/api/cards/${row.dataset.id}`, { front: f.value, back: b.value }, 'PUT'); toast('Card saved.'); }
      else if (row && t.matches('[data-del]') && confirm('Delete this card?')) { await api(`/api/cards/${row.dataset.id}`, undefined, 'DELETE'); row.remove(); toast('Card deleted.'); }
    } catch (err) { toast(err.message); }
  };
}

// ---- Wiring ----
document.addEventListener('keydown', e => {
  if (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || !$('#modal').classList.contains('hidden') || document.body.classList.contains('ovl') || e.ctrlKey || e.metaKey) return;
  if (S.view === 'test' && e.code === 'Space') { e.preventDefault(); return $('#tq').classList.toggle('flipped'); }
  if (S.view === 'test' && /^[1-4]$/.test(e.key)) return pick(+e.key - 1);
  if (S.view !== 'study') return;
  if (e.code === 'Space') { e.preventDefault(); flip($('#ci'), f => { S.flipped = f; $('#rate').classList.toggle('off', !f); }); }
  else if (/^[0-5]$/.test(e.key)) rate(+e.key);
});
document.querySelectorAll('nav button').forEach(b => b.onclick = () => ({ home: showHome, decks: showDecks, tests: showTests, board: showBoard, curve: showCurve }[b.dataset.view])());
$('#logo').onclick = showHome; $('#addBtn').onclick = openModal;
$('#theme').onclick = () => { const d = document.documentElement.dataset.theme === 'dark' ? '' : 'dark'; document.documentElement.dataset.theme = d; localStorage.setItem('rr-theme', d); };
document.documentElement.dataset.theme = localStorage.getItem('rr-theme') || '';
refreshMe().then(showHome).catch(e => app.innerHTML = `<p class="sub">Could not reach the server: ${esc(e.message)}. Run <code>npm start</code>.</p>`);
// Any request that fails without a local handler still tells the user instead of failing silently.
window.addEventListener('unhandledrejection', e => { toast((e.reason && e.reason.message) || 'Something went wrong. Please try again.'); e.preventDefault(); });
