'use strict';
const fs = require('fs'), os = require('os'), path = require('path');
const seed = require('../server/seed');
const { JsonStore } = require('../server/store/json-store');
const { createApp } = require('../server/app');
const config = require('../server/config');

/** Fresh temp directory, so tests never touch the real db.json. */
const tmpDir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'rr-test-'));

/** Start the real app on a random port with a throwaway store. Returns helpers for calling it. */
async function startApp({ cfg = config, fetchImpl } = {}) {
  const dir = tmpDir(), store = new JsonStore(dir, seed).init();
  const server = await new Promise(ok => { const s = createApp(store, { cfg, fetchImpl }).listen(0, () => ok(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, url, body, headers = {}) => {
    const res = await fetch(base + url, { method, headers: { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...headers },
      body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body) });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch {}
    return { status: res.status, json, text, headers: res.headers };
  };
  return { base, store, dir, call, close: () => new Promise(ok => server.close(ok)) };
}
module.exports = { tmpDir, startApp };
