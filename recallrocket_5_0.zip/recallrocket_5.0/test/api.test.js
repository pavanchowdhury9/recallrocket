'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const { startApp } = require('./helpers');
const config = require('../server/config');

let t;
test.before(async () => { t = await startApp(); });
test.after(() => t.close());

test('health check and security headers', async () => {
  const r = await t.call('GET', '/api/health');
  assert.equal(r.status, 200); assert.equal(r.json.ok, true);
  assert.match(r.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.equal(r.headers.get('x-powered-by'), null);
  assert.equal(r.headers.get('cache-control'), 'no-store');
});

test('unknown API routes return JSON 404', async () => {
  const r = await t.call('GET', '/api/nope'); assert.equal(r.status, 404); assert.equal(r.json.error, 'Not found');
});

test('malformed JSON, wrong content type and oversized bodies are rejected cleanly', async () => {
  assert.equal((await t.call('POST', '/api/decks', '{bad json')).status, 400);
  assert.equal((await t.call('POST', '/api/decks', 'name=x', { 'content-type': 'text/plain' })).status, 415);
  assert.equal((await t.call('POST', '/api/decks', JSON.stringify({ name: 'x', pad: 'y'.repeat(3_000_000) }))).status, 413);
});

test('cross-origin writes are blocked (CSRF guard), same-origin and non-browser writes pass', async () => {
  assert.equal((await t.call('POST', '/api/decks', { name: 'evil' }, { origin: 'https://evil.example' })).status, 403);
  assert.equal((await t.call('POST', '/api/decks', { name: 'ok' }, { origin: t.base })).status, 201);
  assert.equal((await t.call('POST', '/api/decks', { name: 'ok2' })).status, 201);
});

test('deck and card validation', async () => {
  assert.equal((await t.call('POST', '/api/decks', { name: '   ' })).status, 400);
  assert.equal((await t.call('POST', '/api/decks', { name: 'x'.repeat(81) })).status, 400);
  assert.equal((await t.call('POST', '/api/decks', { name: 123 })).status, 400);
  assert.equal((await t.call('POST', '/api/cards', { deckId: 9999, front: 'a', back: 'b' })).status, 404);
  assert.equal((await t.call('POST', '/api/cards', { deckId: 1, front: '', back: 'b' })).status, 400);
  assert.equal((await t.call('POST', '/api/cards', { deckId: 1, front: 'a', back: 'x'.repeat(2001) })).status, 400);
  assert.equal((await t.call('GET', '/api/decks/abc/cards')).status, 400);
});

test('create, edit and delete a card; deleting a deck removes its cards', async () => {
  const d = (await t.call('POST', '/api/decks', { name: 'Temp deck' })).json;
  const c = (await t.call('POST', '/api/cards', { deckId: d.id, front: 'Q', back: 'A' })).json;
  assert.equal(c.nextReviewDate, new Date().toISOString().slice(0, 10));
  assert.equal((await t.call('PUT', `/api/cards/${c.id}`, { front: 'Q2', back: 'A2' })).json.front, 'Q2');
  assert.equal((await t.call('DELETE', `/api/cards/${c.id}`)).status, 200);
  assert.equal((await t.call('DELETE', `/api/cards/${c.id}`)).status, 404);
  await t.call('POST', '/api/cards', { deckId: d.id, front: 'Q3', back: 'A3' });
  assert.equal((await t.call('DELETE', `/api/decks/${d.id}`)).status, 200);
  assert.equal(t.store.db.cards.filter(x => x.deckId === d.id).length, 0);
});

test('a deck used by a test cannot be deleted', async () => {
  assert.equal((await t.call('DELETE', '/api/decks/1')).status, 409);
});

test('reviewing a card applies SM-2, updates the streak, and rejects bad input', async () => {
  const before = (await t.call('GET', '/api/me')).json;
  const r = await t.call('POST', '/api/review', { cardId: 1, grade: 5 });
  assert.equal(r.status, 200); assert.equal(r.json.interval, 6); // seeded as already reviewed once
  assert.equal(r.json.streakChanged, true); assert.equal(r.json.user.streak, before.streak + 1);
  for (const body of [{ cardId: 1, grade: 6 }, { cardId: 1, grade: 'x' }, { cardId: 'x', grade: 3 }, {}]) assert.equal((await t.call('POST', '/api/review', body)).status, 400);
  assert.equal((await t.call('POST', '/api/review', { cardId: 99999, grade: 3 })).status, 404);
});

test('tests are graded on the server; the answer key is never sent, foreign and duplicate answers are ignored', async () => {
  const start = (await t.call('POST', '/api/assignments/1/start', {})).json;
  assert.equal(start.questions.length, 5);
  assert.ok(!JSON.stringify(start).includes('"correct"'));
  const q = start.questions[0], truth = t.store.db.cards.find(c => c.id === q.cardId).back;
  const foreign = t.store.db.cards.find(c => c.deckId !== 1);
  const r = (await t.call('POST', '/api/assignments/1/submit', { answers: [
    { cardId: q.cardId, choice: truth }, { cardId: q.cardId, choice: truth }, { cardId: foreign.id, choice: foreign.back } ] })).json;
  assert.equal(r.total, 1); assert.equal(r.score, 1);
  assert.equal((await t.call('POST', '/api/assignments/1/submit', { answers: [] })).status, 400);
  assert.equal((await t.call('POST', '/api/assignments/1/submit', { answers: [{ cardId: foreign.id, choice: 'x' }] })).status, 400);
  assert.equal((await t.call('POST', '/api/assignments/999/submit', { answers: [{ cardId: 1, choice: 'x' }] })).status, 404);
  assert.equal((await t.call('POST', '/api/assignments/1/submit', { answers: Array(51).fill({ cardId: 1, choice: 'x' }) })).status, 400);
});

test('CSV export is formula-safe and import validates its input', async () => {
  const d = (await t.call('POST', '/api/decks', { name: 'Import "me"\r\n' })).json;
  const imp = await t.call('POST', `/api/decks/${d.id}/import`, { csv: 'front,back\n"What?","=cmd|\' /C calc\'!A0"\nQ2,A2' });
  assert.equal(imp.json.added, 2);
  const exp = await t.call('GET', `/api/decks/${d.id}/export`);
  assert.match(exp.text, /"'=cmd/); assert.match(exp.headers.get('content-disposition'), /^attachment; filename="[\w-]+\.csv"$/);
  assert.equal((await t.call('POST', `/api/decks/${d.id}/import`, { csv: 'just one column' })).status, 400);
  assert.equal((await t.call('POST', `/api/decks/${d.id}/import`, { csv: 5 })).status, 400);
  assert.equal((await t.call('POST', '/api/decks/9999/import', { csv: 'a,b' })).status, 404);
});

test('read endpoints used by the dashboard respond with the expected shapes', async () => {
  const get = async u => { const r = await t.call('GET', u); assert.equal(r.status, 200, u); return r.json; };
  assert.ok((await get('/api/courses')).length >= 2);
  assert.equal((await get('/api/performance')).days.length, 14);
  assert.equal((await get('/api/heatmap')).days.length, 91);
  assert.ok(Array.isArray(await get('/api/weak')));
  assert.ok(Array.isArray(await get('/api/due')));
  assert.equal((await get('/api/leaderboard?by=bogus'))[0].rank, 1); // unknown sort falls back to overall
  const ins = await get('/api/insights');
  assert.equal(ins.forecast.length, 7); assert.ok(ins.predictedRetention === null || (ins.predictedRetention >= 0 && ins.predictedRetention <= 100));
});

test('AI endpoint: 501 without a key; with a key it proxies, times errors safely and hides upstream details', async () => {
  const saved = process.env.ANTHROPIC_API_KEY; delete process.env.ANTHROPIC_API_KEY;
  try {
    assert.equal((await t.call('POST', '/api/ai', { prompt: 'hi' })).status, 501);
    process.env.ANTHROPIC_API_KEY = 'sk-test-secret';
    let seen;
    const ok = await startApp({ fetchImpl: async (url, o) => { seen = { url, o }; return { ok: true, json: async () => ({ content: [{ text: 'hello' }] }) }; } });
    const r = await ok.call('POST', '/api/ai', { system: 's', prompt: 'p' });
    assert.equal(r.json.text, 'hello'); assert.equal(seen.o.headers['x-api-key'], 'sk-test-secret');
    assert.ok(!r.text.includes('sk-test-secret'));
    assert.equal((await ok.call('POST', '/api/ai', { system: 's' })).status, 400);
    await ok.close();
    const bad = await startApp({ fetchImpl: async () => ({ ok: false, status: 500, json: async () => ({ error: { message: 'secret internal detail' } }) }) });
    const e = await bad.call('POST', '/api/ai', { prompt: 'p' });
    assert.equal(e.status, 502); assert.ok(!e.text.includes('secret internal detail'));
    await bad.close();
  } finally { if (saved === undefined) delete process.env.ANTHROPIC_API_KEY; else process.env.ANTHROPIC_API_KEY = saved; }
});

test('rate limiting returns 429 with Retry-After', async () => {
  const tight = await startApp({ cfg: { ...config, RATE: { ...config.RATE, READ_PER_WINDOW: 3 } } });
  const codes = []; let last;
  for (let i = 0; i < 5; i++) { last = await tight.call('GET', '/api/health'); codes.push(last.status); }
  assert.deepEqual(codes, [200, 200, 200, 429, 429]); assert.ok(Number(last.headers.get('retry-after')) > 0);
  await tight.close();
});
