'use strict';
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('fs'), path = require('path');
const seed = require('../server/seed');
const { JsonStore } = require('../server/store/json-store');
const { tmpDir } = require('./helpers');

test('updates are persisted and survive a restart', () => {
  const dir = tmpDir(); new JsonStore(dir, seed).init().update(db => { db.cards[0].front = 'edited'; });
  assert.equal(new JsonStore(dir, seed).init().db.cards[0].front, 'edited');
});
test('a failing update changes nothing in memory or on disk (all-or-nothing)', () => {
  const dir = tmpDir(), s = new JsonStore(dir, seed).init(), before = s.db.cards[0].front;
  assert.throws(() => s.update(db => { db.cards[0].front = 'half done'; throw new Error('boom'); }), /boom/);
  assert.equal(s.db.cards[0].front, before);
  assert.equal(new JsonStore(dir, seed).init().db.cards[0].front, before);
});
test('a failed disk write rolls the in-memory data back too', () => {
  const s = new JsonStore(tmpDir(), seed).init(), before = s.db.cards.length;
  s._write = () => { throw new Error('disk full'); };
  assert.throws(() => s.update(db => { db.cards.pop(); }), /disk full/);
  assert.equal(s.db.cards.length, before);
});
test('a corrupted db.json recovers from the backup', () => {
  const dir = tmpDir(), s = new JsonStore(dir, seed).init();
  s.update(db => { db.cards[0].front = 'v1'; }); s.update(db => { db.cards[0].front = 'v2'; }); // second write creates .bak holding v1
  fs.writeFileSync(path.join(dir, 'db.json'), '{ not json');
  const s2 = new JsonStore(dir, seed).init();
  assert.equal(s2.db.cards[0].front, 'v1');
  assert.ok(fs.readdirSync(dir).some(f => f.startsWith('db.json.corrupt-')), 'corrupt file is kept for inspection');
});
test('no temp file is left behind after a write', () => {
  const dir = tmpDir(); new JsonStore(dir, seed).init().update(db => { db.users[0].streak++; });
  assert.ok(!fs.existsSync(path.join(dir, 'db.json.tmp')));
});
let sqliteOk = true; try { require('node:sqlite'); } catch { sqliteOk = false; }
test('SQLite adapter persists changes (Node 22.5+)', { skip: !sqliteOk }, () => {
  const { SqliteStore } = require('../server/store/sqlite-store'), dir = tmpDir();
  const a = new SqliteStore(dir, seed).init(); a.update(db => { db.cards[1].back = 'sqlite works'; }); a.close();
  const b = new SqliteStore(dir, seed).init(); assert.equal(b.db.cards[1].back, 'sqlite works'); b.close();
});
