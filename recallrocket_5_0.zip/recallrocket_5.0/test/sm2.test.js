'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const { sm2, addDays, MIN_EASE } = require('../server/sm2');

test('perfect recalls follow the 1 -> 6 -> 16 day schedule', () => {
  let c = { interval: 0, repetitions: 0, easeFactor: 2.5 }; const seq = [];
  for (let i = 0; i < 3; i++) { c = { ...c, ...sm2(c, 5, '2026-01-01') }; seq.push(c.interval); }
  assert.deepEqual(seq, [1, 6, 16]);
});
test('the ease factor never drops below the 1.3 floor, and failing restarts the card', () => {
  let h = { interval: 6, repetitions: 2, easeFactor: 1.4 };
  for (let i = 0; i < 5; i++) h = { ...h, ...sm2(h, 0, '2026-01-01') };
  assert.ok(h.easeFactor >= MIN_EASE); assert.equal(h.interval, 1); assert.equal(h.repetitions, 0);
});
test('grade 3 passes but lowers the ease factor; grade 5 raises it', () => {
  assert.ok(sm2({ easeFactor: 2.5 }, 3, '2026-01-01').easeFactor < 2.5);
  assert.ok(sm2({ easeFactor: 2.5 }, 5, '2026-01-01').easeFactor > 2.5);
});
test('the next review date is computed from the review date', () => {
  assert.equal(sm2({}, 5, '2026-02-27').nextReviewDate, '2026-02-28');
  assert.equal(addDays('2026-12-31', 1), '2027-01-01');
});
test('invalid grades are rejected', () => {
  for (const g of [-1, 6, 2.5, NaN, '4', null, undefined]) assert.throws(() => sm2({}, g), RangeError);
});
