'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const csv = require('../server/csv');
const opts = { maxRows: 1000, maxCell: 2000 };

test('parses quoted commas, escaped quotes and multi-line cells', () => {
  assert.deepEqual(csv.parse('front,back\n"a, b","say ""hi"""\n"two\nlines",x', opts),
    [['front', 'back'], ['a, b', 'say "hi"'], ['two\nlines', 'x']]);
});
test('accepts tab-separated Anki exports and skips comment lines', () => {
  assert.deepEqual(csv.parse('#deck:x\nq1\ta1\nq2\ta2', opts), [['q1', 'a1'], ['q2', 'a2']]);
});
test('drops rows with a missing side and strips control characters', () => {
  assert.deepEqual(csv.parse('only-one\nq,\u0000a', opts), [['q', 'a']]);
});
test('truncates oversized cells and stops early on huge inputs', () => {
  assert.equal(csv.parse('q,' + 'x'.repeat(5000), opts)[0][1].length, 2000);
  assert.ok(csv.parse('a,b\n'.repeat(5000), { maxRows: 10, maxCell: 50 }).length <= 12);
});
test('export protects against spreadsheet formula injection, and import round-trips it', () => {
  for (const evil of ['=HYPERLINK("http://x")', '+1+1', '-2+3', '@SUM(A1)']) {
    const out = csv.cell(evil); assert.ok(out.startsWith('"\''), out);
    assert.equal(csv.parse(`q,${out}`, opts)[0][1], evil);
  }
  assert.equal(csv.cell('normal'), '"normal"');
});
