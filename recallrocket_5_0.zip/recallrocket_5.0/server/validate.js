'use strict';
/** Small, dependency-free input validators. Each returns a cleaned value or throws a 400. */
const { bad } = require('./errors');
const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g; // keeps \t \n \r

const id = (v, label = 'id') => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < 1) throw bad(`Invalid ${label}`);
  return n;
};
const text = (v, label, max, { required = true } = {}) => {
  if (v === undefined || v === null || v === '') { if (required) throw bad(`${label} is required`); return ''; }
  if (typeof v !== 'string') throw bad(`${label} must be text`);
  const s = v.replace(CONTROL, '').trim();
  if (required && !s) throw bad(`${label} is required`);
  if (s.length > max) throw bad(`${label} must be at most ${max} characters`);
  return s;
};
const grade = v => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < 0 || n > 5) throw bad('Invalid grade (0-5)');
  return n;
};
const object = (v, label = 'Request body') => {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw bad(`${label} must be a JSON object`);
  return v;
};
module.exports = { id, text, grade, object, CONTROL };
