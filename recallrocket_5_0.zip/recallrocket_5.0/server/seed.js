const { today, addDays } = require('./sm2');
const D = {
  'Algorithms': [
    ['What is the time complexity of **QuickSort**?', 'Average `O(n log n)`; worst case `O(n²)` with poor pivots.'],
    ['Time complexity of binary search?', '`O(log n)`. The input must be sorted.'],
    ['MergeSort: time and extra space?', '`O(n log n)` always, `O(n)` extra space. It is stable.'],
    ['Which data structure drives BFS vs DFS?', 'BFS uses a **queue**; DFS uses a **stack** (or recursion).'],
    ["Why does Dijkstra's algorithm fail on some graphs?", 'Negative edge weights. Use **Bellman-Ford** instead.'],
    ['Two properties a problem needs for dynamic programming?', 'Overlapping subproblems and optimal substructure.'],
    ['Greedy vs DP?', 'Greedy commits to the local best choice; DP combines solutions of subproblems.'],
    ['Time complexity of building a heap from n items?', '`O(n)` using bottom-up heapify.'],
    ['Topological sort works on which graphs?', 'Directed acyclic graphs (DAGs).'],
    ["What does Kadane's algorithm solve?", 'Maximum subarray sum in `O(n)` time.']],
  'Data Structures': [
    ['Two ways to resolve hash collisions?', '**Chaining** and **open addressing** (linear/quadratic probing, double hashing).'],
    ['Stack vs queue ordering?', 'Stack is **LIFO**; queue is **FIFO**.'],
    ['Worst-case lookup in an unbalanced BST?', '`O(n)`: it degenerates into a linked list.'],
    ['What does an AVL tree guarantee?', 'Height difference between subtrees is at most 1, so operations are `O(log n)`.'],
    ['What is a trie best for?', 'Prefix search and autocomplete over strings.'],
    ['Min-heap property?', 'Every parent is less than or equal to its children.'],
    ['Array vs linked list access?', 'Array: `O(1)` random access. Linked list: `O(n)`, but `O(1)` insert at a known node.'],
    ['How do you build an LRU cache with O(1) ops?', 'Hash map plus doubly linked list.'],
    ['Adjacency list vs matrix?', 'List: `O(V+E)` space, good for sparse graphs. Matrix: `O(V²)`, `O(1)` edge check.'],
    ['What is a Bloom filter?', 'Probabilistic set: no false negatives, possible false positives.']],
  'OS & Databases': [
    ['Four conditions for deadlock?', 'Mutual exclusion, hold and wait, no preemption, circular wait.'],
    ['Process vs thread?', 'Threads share a process address space; processes are isolated.'],
    ['What does ACID stand for?', 'Atomicity, Consistency, Isolation, Durability.'],
    ['Why do databases use B-tree indexes?', 'Few disk reads per lookup and efficient range queries.'],
    ['What does 3NF remove?', 'Transitive dependencies of non-key attributes on the key.'],
    ['What is paging?', 'Memory split into fixed-size pages mapped to frames, avoiding external fragmentation.'],
    ['Mutex vs semaphore?', 'A mutex has one owner (lock); a semaphore is a counter that allows N concurrent holders.'],
    ['INNER vs LEFT JOIN?', 'INNER keeps matches only; LEFT keeps all left rows, with NULLs when unmatched.'],
    ['CAP theorem?', 'During a partition, choose between consistency and availability.'],
    ['TCP vs UDP?', 'TCP: reliable, ordered, connection-based. UDP: connectionless, low latency.']],
  'OOP & Web': [
    ['Four pillars of OOP?', 'Encapsulation, abstraction, inheritance, polymorphism.'],
    ['What does the S in SOLID mean?', 'Single Responsibility: a class has one reason to change.'],
    ['What is polymorphism?', 'One interface, many implementations, resolved at compile or run time.'],
    ['What makes an API RESTful?', 'Stateless, resource-based URLs, standard HTTP verbs.'],
    ['404 vs 500?', '404: resource not found (client). 500: unexpected server error.'],
    ['What is a closure in JavaScript?', 'A function that remembers variables from its defining scope.'],
    ['What does the JS event loop do?', 'Pushes queued callbacks onto the call stack when it is empty.'],
    ['`==` vs `===` in JavaScript?', '`==` coerces types; `===` compares value and type.'],
    ['What is CORS?', 'Browser policy controlling which origins may read cross-origin responses.'],
    ['Average lookup in a hash map?', '`O(1)` on average, `O(n)` worst case.']]
};
// name, reviews, streak, retention points -> composite = reviews + streak*10 + retention
const FRIENDS = [['Aisha K.', 300, 12, 100], ['Rohan M.', 200, 8, 40], ['Meera S.', 180, 9, 30],
  ['Kabir T.', 120, 5, 50], ['Sana P.', 110, 4, 30], ['Dev R.', 90, 3, 30], ['Ishaan V.', 60, 2, 10], ['Tara N.', 30, 1, 0]];

module.exports = function seed() {
  const t = today(), db = { users: [], courses: [
    { id: 1, name: 'Placement Prep', description: 'Algorithms and data structures for coding rounds' },
    { id: 2, name: 'Core CS Fundamentals', description: 'Operating systems, databases and web basics' }],
    decks: [], cards: [], logs: [], assignments: [], results: [] };
  db.users.push({ id: 1, name: 'You', streak: 6, longestStreak: 6, lastStudyDate: addDays(t, -1), totalReviews: 110, retentionPoints: 90 });
  FRIENDS.forEach(([name, r, s, p], i) => db.users.push({ id: i + 2, name, streak: s, longestStreak: s, lastStudyDate: t, totalReviews: r, retentionPoints: p }));
  let cid = 1;
  Object.entries(D).forEach(([name, cards], i) => {
    db.decks.push({ id: i + 1, courseId: i < 2 ? 1 : 2, name, description: `${cards.length} interview essentials` });
    cards.forEach(([front, back], j) => db.cards.push({ id: cid++, deckId: i + 1, front, back,
      interval: j < 5 ? 1 : 6, repetitions: j < 5 ? 1 : 2, easeFactor: 2.5, nextReviewDate: j < 5 ? t : addDays(t, 3) })); // 5 due today per deck
  });
  // 13 days of past study history so the performance graph is not empty (accuracy improves over time)
  const plan = [[13, 6], [12, 0], [11, 9], [10, 11], [9, 0], [8, 12], [7, 0], [6, 8], [5, 14], [4, 12], [3, 15], [2, 13], [1, 16]];
  let lid = 1;
  plan.forEach(([ago, n], k) => {
    const good = Math.round(n * (0.55 + 0.03 * k));
    for (let i = 0; i < n; i++) db.logs.push({ id: lid++, userId: 1, cardId: 1 + (i * 3 + k) % 40, grade: i < good ? (i % 3 ? 4 : 5) : 2,
      reviewedAt: addDays(t, -ago) + 'T10:00:00.000Z', intervalAfter: 6 });
  });
  db.assignments.push(
    { id: 1, courseId: 1, deckId: 1, title: 'Sorting & Searching Quiz', due: addDays(t, 2), questions: 5 },
    { id: 2, courseId: 1, deckId: 2, title: 'Data Structures Mid-test', due: addDays(t, 5), questions: 5 },
    { id: 3, courseId: 2, deckId: 3, title: 'OS & Databases Basics', due: addDays(t, -1), questions: 5 },
    { id: 4, courseId: 2, deckId: 4, title: 'OOP Warm-up', due: addDays(t, -2), questions: 5 },
    { id: 5, courseId: 1, deckId: 1, title: 'Algorithms Warm-up', due: addDays(t, -6), questions: 5 });
  db.results.push(
    { id: 1, userId: 1, assignmentId: 5, score: 3, total: 5, date: addDays(t, -7) + 'T12:00:00.000Z' },
    { id: 2, userId: 1, assignmentId: 4, score: 4, total: 5, date: addDays(t, -3) + 'T12:00:00.000Z' });
  return db;
};
