'use strict';
/**
 * Storage contract used by the routes. An adapter only implements:
 *   _read()            -> the full db object, or null when nothing is stored yet
 *   _write(db, changed)-> durably persist `db`; `changed` lists the collections that differ
 * Everything else (seeding, copy-on-write transactions, rollback) lives here, so the
 * route code never knows whether data sits in a JSON file or in SQLite.
 */
const COLLECTIONS = ['users', 'courses', 'decks', 'cards', 'logs', 'assignments', 'results'];

class Store {
  constructor(seed) { this.seed = seed; this.db = null; this.fingerprints = {}; }

  init() {
    let db = null;
    try { db = this._read(); } catch (e) { console.error('[store] could not read data, will reseed:', e.message); }
    if (!db || !COLLECTIONS.every(k => Array.isArray(db[k]))) { db = this.seed(); this._write(db, COLLECTIONS); }
    this.db = db; this._fingerprint(db);
    return this;
  }

  /**
   * Run `fn(draft)` on a copy of the data and persist it. If `fn` throws or the write fails,
   * the live data is untouched, so memory and disk can never disagree (all-or-nothing).
   */
  update(fn) {
    const draft = structuredClone(this.db);
    const result = fn(draft);
    const changed = COLLECTIONS.filter(k => JSON.stringify(draft[k]) !== this.fingerprints[k]);
    if (changed.length) { this._write(draft, changed); this.db = draft; this._fingerprint(draft); }
    return result;
  }

  _fingerprint(db) { COLLECTIONS.forEach(k => { this.fingerprints[k] = JSON.stringify(db[k]); }); }
  reset() { this.db = this.seed(); this._write(this.db, COLLECTIONS); this._fingerprint(this.db); }
  close() {}
}
module.exports = { Store, COLLECTIONS };
