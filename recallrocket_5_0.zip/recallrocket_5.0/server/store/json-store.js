'use strict';
const fs = require('fs'), path = require('path');
const { Store } = require('./base');

/**
 * Flat-file adapter with crash-safe writes:
 *   1. write to db.json.tmp and fsync   2. keep the previous file as db.json.bak   3. atomic rename.
 * A power cut can therefore never leave a half-written db.json, and a corrupted file falls back to the backup.
 */
class JsonStore extends Store {
  constructor(dir, seed) {
    super(seed);
    this.file = path.join(dir, 'db.json');
    this.tmp = this.file + '.tmp';
    this.bak = this.file + '.bak';
  }
  _readFile(f) { return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : null; }
  _read() {
    try { return this._readFile(this.file); }
    catch (e) {
      console.error('[store] db.json is corrupt, trying backup:', e.message);
      fs.renameSync(this.file, `${this.file}.corrupt-${Date.now()}`);
      return this._readFile(this.bak);
    }
  }
  _write(db) {
    const fd = fs.openSync(this.tmp, 'w');
    try { fs.writeSync(fd, JSON.stringify(db, null, 1)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    if (fs.existsSync(this.file)) fs.copyFileSync(this.file, this.bak);
    fs.renameSync(this.tmp, this.file);
  }
}
module.exports = { JsonStore };
