'use strict';
const path = require('path');
const { Store, COLLECTIONS } = require('./base');

/**
 * SQLite adapter (built-in `node:sqlite`, Node 22.5+, no npm dependency).
 * One table per collection (id PRIMARY KEY + JSON document). Writes run inside a single
 * transaction in WAL mode, so a multi-collection change is atomic and concurrent readers are safe.
 */
class SqliteStore extends Store {
  constructor(dir, seed) {
    super(seed);
    const { DatabaseSync } = require('node:sqlite'); // throws on older Node; caller falls back to JSON
    this.sql = new DatabaseSync(path.join(dir, 'recallrocket.sqlite'));
    this.sql.exec('PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL;');
    COLLECTIONS.forEach(k => this.sql.exec(`CREATE TABLE IF NOT EXISTS ${k} (id INTEGER PRIMARY KEY, doc TEXT NOT NULL)`));
  }
  _read() {
    const db = {}; let any = false;
    for (const k of COLLECTIONS) {
      const rows = this.sql.prepare(`SELECT doc FROM ${k} ORDER BY id`).all();
      any = any || rows.length > 0;
      db[k] = rows.map(r => JSON.parse(r.doc));
    }
    return any ? db : null;
  }
  _write(db, changed) {
    this.sql.exec('BEGIN IMMEDIATE');
    try {
      for (const k of changed) { // table names come from the fixed COLLECTIONS list, never from input
        this.sql.exec(`DELETE FROM ${k}`);
        const ins = this.sql.prepare(`INSERT INTO ${k} (id, doc) VALUES (?, ?)`);
        db[k].forEach(row => ins.run(row.id, JSON.stringify(row)));
      }
      this.sql.exec('COMMIT');
    } catch (e) { this.sql.exec('ROLLBACK'); throw e; }
  }
  close() { this.sql.close(); }
}
module.exports = { SqliteStore };
