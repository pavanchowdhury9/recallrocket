'use strict';
const { JsonStore } = require('./json-store');
const { SqliteStore } = require('./sqlite-store');

/** Build the store chosen by config. SQLite quietly falls back to JSON when the runtime does not support it. */
function createStore({ kind, dir, seed }) {
  if (kind === 'sqlite') {
    try { return new SqliteStore(dir, seed).init(); }
    catch (e) { console.warn(`[store] SQLite unavailable (${e.message}); using JSON file storage instead.`); }
  }
  return new JsonStore(dir, seed).init();
}
module.exports = { createStore };
