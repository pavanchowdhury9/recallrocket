'use strict';
/** Central configuration. Every tunable lives here and can be overridden by environment variables. */
const path = require('path');

const int = (name, fallback) => {
  const n = Number.parseInt(process.env[name], 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

module.exports = Object.freeze({
  PORT: int('PORT', 3000),
  STORAGE: process.argv.includes('--sqlite') ? 'sqlite' : (process.env.STORAGE || 'json').toLowerCase(), // 'json' | 'sqlite' (sqlite needs Node 22.5+)
  DATA_DIR: process.env.DATA_DIR || __dirname,
  PUBLIC_DIR: path.join(__dirname, '..', 'public'),
  CURRENT_USER_ID: 1, // single-user demo; every route reads the user from here, never from the request
  LIMITS: Object.freeze({
    BODY_BYTES: '2mb',
    DECK_NAME: 80,
    DECK_DESC: 300,
    CARD_TEXT: 2000,
    CSV_ROWS: 1000,
    CSV_CHARS: 1_500_000,
    TEST_ANSWERS: 50,
    AI_SYSTEM: 2000,
    AI_PROMPT: 20000,
    AI_TIMEOUT_MS: 30000,
  }),
  RATE: Object.freeze({
    WINDOW_MS: 60_000,
    READ_PER_WINDOW: int('RATE_READ', 600),
    WRITE_PER_WINDOW: int('RATE_WRITE', 120),
    AI_PER_WINDOW: int('RATE_AI', 10),
  }),
  AI_MODEL: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6',
});
