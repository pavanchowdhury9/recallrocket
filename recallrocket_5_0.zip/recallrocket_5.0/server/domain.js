'use strict';
/** Pure domain helpers shared by the routes. They only read the data they are given. */
const { today, addDays } = require('./sm2');

const nextId = list => list.reduce((m, x) => Math.max(m, x.id), 0) + 1;
const score = u => u.totalReviews + u.streak * 10 + u.retentionPoints;
const RANKERS = {
  score: (a, b) => score(b) - score(a),
  reviews: (a, b) => b.totalReviews - a.totalReviews,
  streak: (a, b) => b.streak - a.streak,
  retention: (a, b) => b.retentionPoints - a.retentionPoints,
};
const ranked = (db, key = 'score') => [...db.users].sort(RANKERS[key] || RANKERS.score);
const rankOf = (db, id, key) => ranked(db, key).findIndex(u => u.id === id) + 1;

const cardState = c => (c.interval >= 6 ? 'mature' : c.interval === 0 ? 'new' : 'learning');
const isDue = (c, t = today()) => c.nextReviewDate <= t;
const newCard = (db, deckId, front, back) => ({
  id: nextId(db.cards), deckId, front, back, interval: 0, repetitions: 0, easeFactor: 2.5, nextReviewDate: today(),
});

function deckStats(db, d) {
  const cs = db.cards.filter(c => c.deckId === d.id), st = { mature: 0, learning: 0, new: 0 };
  cs.forEach(c => st[cardState(c)]++);
  return { ...d, total: cs.length, due: cs.filter(c => isDue(c)).length, ...st };
}
const latestResult = (db, userId, assignmentId) => db.results
  .filter(r => r.userId === userId && r.assignmentId === assignmentId)
  .sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id)[0];

/** Fisher-Yates shuffle on a copy. */
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
const withDeck = (db, c) => ({ ...c, deckName: (db.decks.find(d => d.id === c.deckId) || {}).name || '' });
module.exports = { nextId, score, ranked, rankOf, cardState, isDue, newCard, deckStats, latestResult, shuffle, withDeck, today, addDays };
