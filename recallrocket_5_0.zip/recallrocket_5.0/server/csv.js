'use strict';
/** CSV / Anki parsing and writing, including protection against spreadsheet formula injection. */
const { CONTROL } = require('./validate');

const FORMULA_START = /^[=+\-@\t\r]/;
/** Quote a cell for export. Cells that a spreadsheet could treat as a formula get a leading apostrophe (OWASP CSV injection guidance). */
function cell(value) {
  let s = String(value);
  if (FORMULA_START.test(s)) s = "'" + s;
  return '"' + s.replace(/"/g, '""') + '"';
}
/** Reverse the export protection so export -> import round-trips cleanly. */
const unprotect = s => (/^'[=+\-@]/.test(s) ? s.slice(1) : s);

/** Parse comma- or tab-separated text into [front, back] rows. Enforces row/cell limits. */
function parse(text, { maxRows, maxCell }) {
  // Detect the delimiter from the first real line, skipping blanks and Anki "#..." header lines.
  const first = text.split(/\r?\n/).find(l => l.trim() && !l.startsWith('#')) || '';
  const delim = first.includes('\t') ? '\t' : ',';
  const rows = []; let row = [], c = '', quoted = false;
  const endRow = () => { row.push(c); rows.push(row); row = []; c = ''; };
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') { if (text[i + 1] === '"') { c += '"'; i++; } else quoted = false; } else c += ch;
    } else if (ch === '"' && c === '') quoted = true;
    else if (ch === delim) { row.push(c); c = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; endRow(); }
    else c += ch;
    if (rows.length > maxRows + 1) break; // stop early on oversized input
  }
  if (c || row.length) { row.push(c); rows.push(row); }
  return rows
    .map(r => r.slice(0, 2).map(x => unprotect(x.replace(CONTROL, '').trim())))
    .filter(r => r.length === 2 && r[0] && r[1] && !r[0].startsWith('#'))
    .map(r => r.map(x => x.slice(0, maxCell)));
}
module.exports = { cell, parse, unprotect };
