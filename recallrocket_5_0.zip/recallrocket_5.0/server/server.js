'use strict';
const config = require('./config');
const seed = require('./seed');
const { createStore } = require('./store');
const { createApp } = require('./app');

const store = createStore({ kind: config.STORAGE, dir: config.DATA_DIR, seed });
const app = createApp(store);

const server = app.listen(config.PORT, () => {
  console.log(`RecallRocket running at http://localhost:${config.PORT}  (storage: ${store.constructor.name})`);
  if (!process.env.ANTHROPIC_API_KEY) console.log('AI features use the built-in rules engine (set ANTHROPIC_API_KEY to enable real AI).');
});
server.on('error', e => {
  console.error(e.code === 'EADDRINUSE' ? `Port ${config.PORT} is already in use. Try: PORT=3001 npm start` : e);
  process.exit(1);
});

// Finish in-flight requests, close the database, then exit. A timer guarantees we never hang on shutdown.
let closing = false;
function shutdown(signal) {
  if (closing) return; closing = true;
  console.log(`\n${signal} received, shutting down...`);
  server.close(() => { store.close(); process.exit(0); });
  setTimeout(() => process.exit(1), 5000).unref();
}
['SIGINT', 'SIGTERM'].forEach(s => process.on(s, () => shutdown(s)));
process.on('unhandledRejection', e => console.error('[unhandledRejection]', e));
process.on('uncaughtException', e => { console.error('[uncaughtException]', e); shutdown('uncaughtException'); });
