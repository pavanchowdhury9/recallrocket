'use strict';
const express = require('express');
const config = require('./config');
const { securityHeaders, sameOriginWrites } = require('./middleware/security');
const { rateLimit } = require('./middleware/rate-limit');
const { apiNotFound, errorHandler } = require('./middleware/errors');

/**
 * Build the Express app around a store. Keeping this separate from server.js means tests can create the
 * whole app against a temporary store without opening a port.
 */
function createApp(store, { fetchImpl, cfg = config } = {}) {
  const app = express();
  app.disable('x-powered-by');
  if (process.env.TRUST_PROXY) app.set('trust proxy', process.env.TRUST_PROXY);

  app.use(securityHeaders);
  app.use(express.static(cfg.PUBLIC_DIR, { dotfiles: 'ignore', index: 'index.html' }));

  const api = express.Router();
  api.use(rateLimit({ windowMs: cfg.RATE.WINDOW_MS, max: cfg.RATE.READ_PER_WINDOW, name: 'requests' }));
  api.use((req, res, next) => (req.method === 'GET' ? next() : rateLimit({ windowMs: cfg.RATE.WINDOW_MS, max: cfg.RATE.WRITE_PER_WINDOW, name: 'changes' })(req, res, next)));
  api.use(sameOriginWrites);
  api.use('/ai', rateLimit({ windowMs: cfg.RATE.WINDOW_MS, max: cfg.RATE.AI_PER_WINDOW, name: 'AI requests' }));
  api.use(express.json({ limit: cfg.LIMITS.BODY_BYTES }));

  api.get('/health', (req, res) => res.json({ ok: true, storage: store.constructor.name, uptime: Math.round(process.uptime()) }));
  const ctx = { store, config: cfg, fetchImpl };
  ['decks', 'study', 'tests', 'io', 'insights', 'ai'].forEach(name => api.use(require(`./routes/${name}`)(ctx)));
  api.use(apiNotFound);

  app.use('/api', api);
  app.use(errorHandler);
  return app;
}
module.exports = { createApp };
