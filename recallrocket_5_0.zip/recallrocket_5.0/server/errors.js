'use strict';
/** An error that is safe to show to the client. Anything else becomes a generic 500. */
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; this.expose = true; }
}
const bad = msg => new HttpError(400, msg);
const notFound = msg => new HttpError(404, msg);
module.exports = { HttpError, bad, notFound };
