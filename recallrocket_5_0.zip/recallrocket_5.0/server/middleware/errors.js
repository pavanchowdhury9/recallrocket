'use strict';
/** Wrap async route handlers so a rejected promise reaches the error handler instead of crashing the process. */
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const apiNotFound = (req, res) => res.status(404).json({ error: 'Not found' });

/** Last-resort handler: exposes only HttpError messages, logs everything else, never leaks stack traces. */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request is too large' });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON' });
  if (err.expose) return res.status(err.status || 400).json({ error: err.message });
  console.error(`[error] ${req.method} ${req.originalUrl}:`, err);
  res.status(500).json({ error: 'Something went wrong on the server. Please try again.' });
}
module.exports = { wrap, apiNotFound, errorHandler };
