'use strict';
/** Fixed-window, in-memory rate limiter keyed by client IP. Enough for a single-process app; swap for Redis if scaled out. */
function rateLimit({ windowMs, max, name = 'requests' }) {
  const hits = new Map();
  const sweep = setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (v.reset <= now) hits.delete(k); }, windowMs);
  sweep.unref(); // never keep the process alive just for cleanup
  return function limiter(req, res, next) {
    const now = Date.now(), key = req.ip || 'unknown';
    let h = hits.get(key);
    if (!h || h.reset <= now) { h = { n: 0, reset: now + windowMs }; hits.set(key, h); }
    h.n++;
    res.setHeader('X-RateLimit-Limit', max);
    res.setHeader('X-RateLimit-Remaining', Math.max(0, max - h.n));
    if (h.n > max) {
      res.setHeader('Retry-After', Math.ceil((h.reset - now) / 1000));
      return res.status(429).json({ error: `Too many ${name}. Please wait a moment and try again.` });
    }
    next();
  };
}
module.exports = { rateLimit };
