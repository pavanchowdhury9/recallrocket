'use strict';
const { HttpError } = require('../errors');

const CSP = [
  "default-src 'self'",
  "script-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com",
  "worker-src 'self' blob: https://cdnjs.cloudflare.com",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com", // inline style="" attributes are used for progress bars
  "font-src 'self' https://fonts.gstatic.com data:",
  "img-src 'self' data: blob:",
  "connect-src 'self' https://cdnjs.cloudflare.com",
  "object-src 'none'", "base-uri 'none'", "form-action 'self'", "frame-ancestors 'none'",
].join('; ');

/** Defence-in-depth response headers (what the `helmet` package would add, without the dependency). */
function securityHeaders(req, res, next) {
  res.setHeader('Content-Security-Policy', CSP);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  next();
}

/**
 * CSRF guard for state-changing requests. Browsers always send Origin on cross-site POSTs, so a request
 * whose Origin host differs from our Host is rejected. Non-browser clients (curl, tests) send no Origin and pass.
 * JSON content type is also required, which a plain HTML form cannot produce.
 */
function sameOriginWrites(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (origin) {
    let host; try { host = new URL(origin).host; } catch { return next(new HttpError(403, 'Bad origin')); }
    if (host !== req.get('host')) return next(new HttpError(403, 'Cross-origin request blocked'));
  }
  if (req.is('application/json') === false) return next(new HttpError(415, 'Content-Type must be application/json')); // null = no body (e.g. DELETE), allowed
  next();
}
module.exports = { securityHeaders, sameOriginWrites, CSP };
