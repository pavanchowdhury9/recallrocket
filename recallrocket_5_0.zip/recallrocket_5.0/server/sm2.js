'use strict';
/**
 * SuperMemo-2 scheduling. Pure functions; dates are UTC "YYYY-MM-DD" strings everywhere.
 * Grades: 0-2 = failed recall (card restarts), 3-5 = successful recall.
 */
const MIN_EASE = 1.3;
const today = () => new Date().toISOString().slice(0, 10);

function addDays(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/**
 * @param {{interval?:number, repetitions?:number, easeFactor?:number}} card current scheduling state
 * @param {number} grade integer 0-5
 * @param {string} [onDate] review date, defaults to today (injectable for tests)
 * @returns {{interval:number, repetitions:number, easeFactor:number, nextReviewDate:string}}
 */
function sm2({ interval = 0, repetitions = 0, easeFactor = 2.5 }, grade, onDate = today()) {
  if (!Number.isInteger(grade) || grade < 0 || grade > 5) throw new RangeError('grade must be an integer from 0 to 5');
  let int = interval, reps = repetitions;
  if (grade >= 3) {
    int = reps === 0 ? 1 : reps === 1 ? 6 : Math.round(int * easeFactor);
    reps += 1;
  } else { reps = 0; int = 1; }
  const q = 5 - grade;
  const ef = Math.max(MIN_EASE, +(easeFactor + (0.1 - q * (0.08 + q * 0.02))).toFixed(2));
  return { interval: int, repetitions: reps, easeFactor: ef, nextReviewDate: addDays(onDate, int) };
}
module.exports = { sm2, today, addDays, MIN_EASE };
