'use strict';
const express = require('express');
const v = require('../validate');
const { HttpError } = require('../errors');
const { wrap } = require('../middleware/errors');

/** Optional AI proxy. The API key stays on the server (environment variable only) and is never sent to the browser. */
module.exports = ({ config, fetchImpl = globalThis.fetch }) => {
  const r = express.Router(), L = config.LIMITS;

  r.post('/ai', wrap(async (req, res) => {
    const key = process.env.ANTHROPIC_API_KEY;
    if (!key) throw new HttpError(501, 'AI key not set');
    const b = v.object(req.body);
    const system = v.text(b.system, 'System prompt', L.AI_SYSTEM, { required: false });
    const prompt = v.text(b.prompt, 'Prompt', L.AI_PROMPT);
    const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), L.AI_TIMEOUT_MS);
    try {
      const up = await fetchImpl('https://api.anthropic.com/v1/messages', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: config.AI_MODEL, max_tokens: 2500, system, messages: [{ role: 'user', content: prompt }] }),
      });
      const j = await up.json().catch(() => ({}));
      if (!up.ok) { console.error('[ai] upstream error', up.status, j.error && j.error.type); throw new HttpError(502, 'The AI service could not answer right now.'); }
      res.json({ text: (j.content || []).map(x => x.text || '').join('') });
    } catch (e) {
      if (e instanceof HttpError) throw e;
      throw new HttpError(504, e.name === 'AbortError' ? 'The AI service took too long to answer.' : 'The AI service is unreachable.');
    } finally { clearTimeout(timer); }
  }));
  return r;
};
