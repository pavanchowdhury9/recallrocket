'use strict';
const express = require('express');
const v = require('../validate');
const { bad, notFound, HttpError } = require('../errors');
const D = require('../domain');

/** Decks and cards: create, read, rename, edit, delete. */
module.exports = ({ store, config }) => {
  const r = express.Router(), L = config.LIMITS;
  const deckOr404 = (db, id) => db.decks.find(d => d.id === id) || (() => { throw notFound('Deck not found'); })();

  r.get('/decks', (req, res) => res.json(store.db.decks.map(d => D.deckStats(store.db, d))));

  r.post('/decks', (req, res) => {
    const b = v.object(req.body), name = v.text(b.name, 'Deck name', L.DECK_NAME);
    const desc = v.text(b.description, 'Description', L.DECK_DESC, { required: false });
    const courseId = Number.isInteger(+b.courseId) && +b.courseId > 0 ? +b.courseId : 0;
    res.status(201).json(store.update(db => {
      const d = { id: D.nextId(db.decks), courseId, name, description: desc };
      db.decks.push(d); return d;
    }));
  });

  r.put('/decks/:id', (req, res) => {
    const id = v.id(req.params.id), b = v.object(req.body), name = v.text(b.name, 'Deck name', L.DECK_NAME);
    res.json(store.update(db => { const d = deckOr404(db, id); d.name = name; return d; }));
  });

  r.delete('/decks/:id', (req, res) => {
    const id = v.id(req.params.id);
    store.update(db => {
      deckOr404(db, id);
      if (db.assignments.some(a => a.deckId === id)) throw new HttpError(409, 'This deck is used by a test, so it cannot be deleted.');
      db.decks = db.decks.filter(d => d.id !== id);
      const gone = new Set(db.cards.filter(c => c.deckId === id).map(c => c.id));
      db.cards = db.cards.filter(c => c.deckId !== id);
      db.logs = db.logs.filter(l => !gone.has(l.cardId));
    });
    res.json({ deleted: id });
  });

  r.get('/decks/:id/cards', (req, res) => res.json(store.db.cards.filter(c => c.deckId === v.id(req.params.id))));
  r.get('/decks/:id/due', (req, res) => res.json(store.db.cards.filter(c => c.deckId === v.id(req.params.id) && D.isDue(c))));

  r.post('/cards', (req, res) => {
    const b = v.object(req.body), deckId = v.id(b.deckId, 'deck');
    const front = v.text(b.front, 'Front', L.CARD_TEXT), back = v.text(b.back, 'Back', L.CARD_TEXT);
    res.status(201).json(store.update(db => {
      deckOr404(db, deckId);
      const c = D.newCard(db, deckId, front, back); db.cards.push(c); return c;
    }));
  });

  r.put('/cards/:id', (req, res) => {
    const id = v.id(req.params.id), b = v.object(req.body);
    const front = v.text(b.front, 'Front', L.CARD_TEXT), back = v.text(b.back, 'Back', L.CARD_TEXT);
    res.json(store.update(db => {
      const c = db.cards.find(x => x.id === id); if (!c) throw notFound('Card not found');
      c.front = front; c.back = back; return c; // scheduling state is intentionally untouched
    }));
  });

  r.delete('/cards/:id', (req, res) => {
    const id = v.id(req.params.id);
    store.update(db => {
      if (!db.cards.some(c => c.id === id)) throw notFound('Card not found');
      db.cards = db.cards.filter(c => c.id !== id);
      db.logs = db.logs.filter(l => l.cardId !== id);
    });
    res.json({ deleted: id });
  });
  return r;
};
