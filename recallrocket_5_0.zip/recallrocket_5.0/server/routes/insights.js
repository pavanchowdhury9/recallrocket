'use strict';
const express = require('express');
const D = require('../domain');

const LEECH_LAPSES = 4; // a card failed this many times is a "leech": it needs a new memory hook, not more repetition

/**
 * Learning analytics built on the SM-2 data:
 *  - forecast: how many reviews fall due on each of the next 7 days (so you can plan your week)
 *  - predictedRetention: average chance of recalling each reviewed card today, using R = e^(-t/S) with S = current interval
 *  - leeches: cards you keep failing, with the decks they belong to
 */
module.exports = ({ store, config }) => {
  const r = express.Router(), ME = config.CURRENT_USER_ID;

  r.get('/insights', (req, res) => {
    const db = store.db, t = D.today();
    const lapses = {}, lastSeen = {};
    db.logs.filter(l => l.userId === ME).forEach(l => {
      if (l.grade < 3) lapses[l.cardId] = (lapses[l.cardId] || 0) + 1;
      const day = l.reviewedAt.slice(0, 10);
      if (!lastSeen[l.cardId] || day > lastSeen[l.cardId]) lastSeen[l.cardId] = day;
    });

    const forecast = [];
    for (let i = 0; i < 7; i++) {
      const d = D.addDays(t, i);
      forecast.push({ date: d, due: db.cards.filter(c => (i === 0 ? c.nextReviewDate <= d : c.nextReviewDate === d)).length });
    }

    const daysBetween = (a, b) => Math.max(0, (Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 864e5);
    const reviewed = db.cards.filter(c => c.interval > 0);
    const predictedRetention = reviewed.length
      ? Math.round(100 * reviewed.reduce((s, c) => s + Math.exp(-daysBetween(lastSeen[c.id] || t, t) / Math.max(1, c.interval)), 0) / reviewed.length)
      : null;

    const leeches = db.cards.filter(c => (lapses[c.id] || 0) >= LEECH_LAPSES)
      .sort((a, b) => lapses[b.id] - lapses[a.id]).slice(0, 10)
      .map(c => ({ ...D.withDeck(db, c), lapses: lapses[c.id] }));

    res.json({ forecast, predictedRetention, leeches, leechThreshold: LEECH_LAPSES, reviewedCards: reviewed.length });
  });
  return r;
};
