'use strict';
const express = require('express');
const v = require('../validate');
const { bad, notFound } = require('../errors');
const D = require('../domain');

/** Courses, multiple-choice tests (graded on the server) and the performance summary. */
module.exports = ({ store, config }) => {
  const r = express.Router(), ME = config.CURRENT_USER_ID, L = config.LIMITS;
  const assignmentOr404 = (db, id) => db.assignments.find(x => x.id === id) || (() => { throw notFound('Test not found'); })();

  r.get('/courses', (req, res) => {
    const db = store.db;
    const list = db.courses.map(c => ({ ...c, decks: db.decks.filter(d => d.courseId === c.id).map(d => D.deckStats(db, d)) }));
    const orphans = db.decks.filter(d => !db.courses.some(c => c.id === d.courseId));
    if (orphans.length) list.push({ id: 0, name: 'My decks', description: 'Decks you created', decks: orphans.map(d => D.deckStats(db, d)) });
    list.forEach(c => ['total', 'due', 'mature', 'learning', 'new'].forEach(k => { c[k] = c.decks.reduce((a, d) => a + d[k], 0); }));
    res.json(list);
  });

  r.get('/assignments', (req, res) => {
    const db = store.db, t = D.today();
    const list = db.assignments.map(a => {
      const res_ = D.latestResult(db, ME, a.id), course = db.courses.find(c => c.id === a.courseId);
      return { ...a, course: course ? course.name : '', status: res_ ? 'done' : a.due < t ? 'overdue' : 'pending',
        score: res_ ? res_.score : null, total: res_ ? res_.total : null };
    });
    list.sort((x, y) => (x.status === 'done') - (y.status === 'done') || x.due.localeCompare(y.due));
    res.json(list);
  });

  r.post('/assignments/:id/start', (req, res) => {
    const db = store.db, a = assignmentOr404(db, v.id(req.params.id));
    const cards = db.cards.filter(c => c.deckId === a.deckId);
    const questions = D.shuffle(cards).slice(0, a.questions).map(c => {
      const others = [...new Set(cards.filter(x => x.id !== c.id && x.back !== c.back).map(x => x.back))];
      return { cardId: c.id, front: c.front, options: D.shuffle([c.back, ...D.shuffle(others).slice(0, 3)]) }; // the answer key never leaves the server
    });
    res.json({ assignment: { id: a.id, title: a.title }, questions });
  });

  r.post('/assignments/:id/submit', (req, res) => {
    const id = v.id(req.params.id), b = v.object(req.body);
    if (!Array.isArray(b.answers) || !b.answers.length) throw bad('No answers submitted');
    if (b.answers.length > L.TEST_ANSWERS) throw bad(`At most ${L.TEST_ANSWERS} answers per submission`);
    res.json(store.update(db => {
      const a = assignmentOr404(db, id), seen = new Set(), review = [];
      for (const an of b.answers) {
        const cardId = v.id(an && an.cardId, 'cardId'), choice = v.text(an.choice, 'Answer', L.CARD_TEXT, { required: false });
        const c = db.cards.find(x => x.id === cardId && x.deckId === a.deckId); // only cards that belong to this test
        if (!c || seen.has(cardId)) continue; // ignore foreign or duplicate answers instead of letting them inflate the score
        seen.add(cardId);
        review.push({ front: c.front, correct: c.back, chosen: choice, ok: c.back === choice });
      }
      if (!review.length) throw bad('No valid answers submitted');
      const score = review.filter(x => x.ok).length;
      db.results.push({ id: D.nextId(db.results), userId: ME, assignmentId: a.id, score, total: review.length, date: new Date().toISOString() });
      return { score, total: review.length, review };
    }));
  });

  r.get('/performance', (req, res) => {
    const db = store.db, t = D.today(), mine = db.logs.filter(l => l.userId === ME), days = [];
    for (let i = 13; i >= 0; i--) {
      const d = D.addDays(t, -i), ls = mine.filter(l => l.reviewedAt.slice(0, 10) === d);
      days.push({ date: d, reviews: ls.length, accuracy: ls.length ? Math.round(100 * ls.filter(l => l.grade >= 3).length / ls.length) : null });
    }
    const tests = db.assignments.map(a => ({ a, r: D.latestResult(db, ME, a.id) })).filter(x => x.r)
      .sort((x, y) => x.r.date.localeCompare(y.r.date))
      .map(({ a, r: rr }) => ({ title: a.title, date: rr.date.slice(0, 10), pct: Math.round(100 * rr.score / rr.total), score: rr.score, total: rr.total }));
    res.json({ days, tests, accuracy: mine.length ? Math.round(100 * mine.filter(l => l.grade >= 3).length / mine.length) : 0,
      avgTest: tests.length ? Math.round(tests.reduce((s, x) => s + x.pct, 0) / tests.length) : null });
  });
  return r;
};
