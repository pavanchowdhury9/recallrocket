'use strict';
const express = require('express');
const v = require('../validate');
const { notFound } = require('../errors');
const { sm2 } = require('../sm2');
const D = require('../domain');

/** Reviewing cards, the streak, the leaderboard, and the study lists (due, weak spots, heatmap). */
module.exports = ({ store, config }) => {
  const r = express.Router(), ME = config.CURRENT_USER_ID;
  const GRADE_POINTS = [0, 0, 0, 3, 6, 10];

  r.post('/review', (req, res) => {
    const b = v.object(req.body), cardId = v.id(b.cardId, 'cardId'), grade = v.grade(b.grade);
    res.json(store.update(db => {
      const card = db.cards.find(c => c.id === cardId); if (!card) throw notFound('Card not found');
      Object.assign(card, sm2(card, grade));
      const u = db.users.find(x => x.id === ME), t = D.today();
      let streakChanged = false;
      if (u.lastStudyDate !== t) {
        u.streak = u.lastStudyDate === D.addDays(t, -1) ? u.streak + 1 : 1;
        u.lastStudyDate = t; streakChanged = true;
        u.longestStreak = Math.max(u.longestStreak, u.streak);
      }
      u.totalReviews += 1; u.retentionPoints += GRADE_POINTS[grade];
      db.logs.push({ id: D.nextId(db.logs), userId: ME, cardId, grade, reviewedAt: new Date().toISOString(), intervalAfter: card.interval });
      return { interval: card.interval, nextReviewDate: card.nextReviewDate, easeFactor: card.easeFactor, streakChanged, user: u, rank: D.rankOf(db, ME) };
    }));
  });

  r.get('/leaderboard', (req, res) => {
    const key = ['score', 'reviews', 'streak', 'retention'].includes(req.query.by) ? req.query.by : 'score';
    res.json(D.ranked(store.db, key).map((u, i) => ({ rank: i + 1, id: u.id, name: u.name, reviews: u.totalReviews,
      streak: u.streak, retention: u.retentionPoints, score: D.score(u), isMe: u.id === ME })));
  });

  r.get('/me', (req, res) => res.json({ ...store.db.users.find(u => u.id === ME), rank: D.rankOf(store.db, ME) }));
  r.get('/due', (req, res) => res.json(store.db.cards.filter(c => D.isDue(c)).map(c => D.withDeck(store.db, c))));

  r.get('/weak', (req, res) => {
    const db = store.db, fails = {};
    db.logs.filter(l => l.userId === ME && l.grade < 3).forEach(l => { fails[l.cardId] = (fails[l.cardId] || 0) + 1; });
    res.json(db.cards.map(c => ({ c, f: fails[c.id] || 0 })).filter(x => x.f > 0 || x.c.easeFactor < 2.3)
      .sort((a, b) => b.f - a.f || a.c.easeFactor - b.c.easeFactor).slice(0, 8)
      .map(x => ({ ...D.withDeck(db, x.c), misses: x.f })));
  });

  r.get('/heatmap', (req, res) => {
    const t = D.today(), counts = {};
    store.db.logs.filter(l => l.userId === ME).forEach(l => { const d = l.reviewedAt.slice(0, 10); counts[d] = (counts[d] || 0) + 1; });
    const days = [];
    for (let i = 90; i >= 0; i--) { const d = D.addDays(t, -i); days.push({ date: d, n: counts[d] || 0 }); }
    res.json({ days, total: days.reduce((a, d) => a + d.n, 0), active: days.filter(d => d.n).length, best: Math.max(0, ...days.map(d => d.n)) });
  });
  return r;
};
