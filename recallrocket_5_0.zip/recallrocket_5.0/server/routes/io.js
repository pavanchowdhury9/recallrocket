'use strict';
const express = require('express');
const v = require('../validate');
const { bad, notFound } = require('../errors');
const csv = require('../csv');
const D = require('../domain');

/** CSV / Anki export and import. */
module.exports = ({ store, config }) => {
  const r = express.Router(), L = config.LIMITS;

  r.get('/decks/:id/export', (req, res) => {
    const d = store.db.decks.find(x => x.id === v.id(req.params.id)); if (!d) throw notFound('Deck not found');
    const body = 'front,back\n' + store.db.cards.filter(c => c.deckId === d.id).map(c => csv.cell(c.front) + ',' + csv.cell(c.back)).join('\n');
    const safeName = d.name.replace(/[^\w-]+/g, '_').replace(/^_+|_+$/g, '') || 'deck'; // no quotes/CRLF can reach the header
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}.csv"`);
    res.end(body);
  });

  r.post('/decks/:id/import', (req, res) => {
    const id = v.id(req.params.id), b = v.object(req.body);
    if (typeof b.csv !== 'string') throw bad('csv must be text');
    if (b.csv.length > L.CSV_CHARS) throw bad('That file is too large to import');
    const rows = csv.parse(b.csv, { maxRows: L.CSV_ROWS, maxCell: L.CARD_TEXT });
    if (rows.length && /^(front|question)$/i.test(rows[0][0])) rows.shift(); // header row
    if (!rows.length) throw bad('No cards found. Use two columns: front, back.');
    if (rows.length > L.CSV_ROWS) throw bad(`At most ${L.CSV_ROWS} cards can be imported at once`);
    res.json(store.update(db => {
      const d = db.decks.find(x => x.id === id); if (!d) throw notFound('Deck not found');
      rows.forEach(([front, back]) => db.cards.push(D.newCard(db, d.id, front, back)));
      return { added: rows.length };
    }));
  });
  return r;
};
