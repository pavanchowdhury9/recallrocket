# RecallRocket 5.0

Spaced-repetition flashcards using SM-2, with a daily streak and a campus leaderboard.

## Run
    npm install
    npm start        # http://localhost:3000
    npm test         # SM-2, CSV, storage and full API test suite (no extra dependencies)
    npm run lint     # syntax + unsafe-code check
    npm run start:sqlite   # optional: SQLite storage instead of the JSON file (Node 22.5+)
    npm run reset    # delete server/db.json and reseed (do this before each demo)

## Demo script
1. Open **Algorithms**: 5 cards due. Flip card 1 with Space, press 5: toast says "Next review in 6 days" (due cards are seeded as already reviewed once).
2. Finish the 5 cards: streak goes 6 to 7, the badge appears, rank goes #4 to #2.
3. Open the leaderboard, then toggle dark mode.

## Dashboard, courses and tests
- **Dashboard** (home): cards due, streak, rank, recall accuracy, average test score, a 14-day performance graph (cards reviewed + accuracy), test score bars, upcoming tests and course progress.
- **Courses**: decks grouped into courses with a mastered / learning / new progress bar.
- **Tests**: multiple-choice tests built from a course deck (keys 1-4). Graded on the server, with a review of right and wrong answers. Seeded with 5 tests (2 done, 1 overdue, 2 pending).
- The first 13 days of study history are seeded so the graph is not empty. Run `npm run reset` after updating so the new data loads.

## Extra features
- **Export CSV**: link on each deck card (columns: front, back).
- **Import CSV / Anki**: on each deck card, choose a .csv or .txt. Two columns (front, back), comma- or tab-separated, so an Anki "Notes in Plain Text" export works. Imported cards are due today.
- **Forgetting curve**: top nav. Needs internet once to load Chart.js from a CDN.

## Notes
- Storage defaults to a JSON file (`server/db.json`, no native dependencies). `npm run start:sqlite` switches to SQLite through the same store interface; no route code changes.
- Dates are UTC `YYYY-MM-DD` strings; the day rolls over at 5:30 AM IST.
- Keys: Space flips, 0-5 rates (SM-2 grades), the Listen button reads aloud (Web Speech API).

## New in 3.0 (animations + features)
**Look and feel**
- Custom cursor (dot + trailing ring, grows on buttons, says FLIP over cards), sparkle trail, click bursts, button ripples, magnetic buttons.
- Animated constellation + aurora background that reacts to the mouse; intro splash with a launching rocket.
- Text effects: scrambling headings that resolve letter by letter, letters that jump on hover, animated marker highlights, gradient shimmer text, typewriter tips.
- Scroll reveals, 3D tilt + spotlight glow on cards, card "deal" animation, sliding nav indicator, scroll progress bar, rocket that rides the study progress bar.
- Feedback: confetti on finishing a session or scoring 80%+ on a test, green/red screen flash and particle burst on every rating, animated charts, count-up numbers.
- Everything honours `prefers-reduced-motion`; cursor effects are disabled on touch devices.

**Features**
- Dashboard hero with XP levels (Cadet to Galaxy Pilot), daily goal ring (click to change 5/10/20/30), 13-week study heatmap.
- **Mixed review** (all due cards) and **Practice weak spots** (most-missed cards). New API: `/api/due`, `/api/weak`, `/api/heatmap`.
- Podium leaderboard with avatars; deck search with highlighted matches.
- **Command palette** (Ctrl/Cmd+K or `/`), shortcuts help (`?`), **focus mode** (`F`), **Pomodoro timer** (`P`), dark mode key (`D`).
- Style panel: 5 accent colours, toggles for cursor effects, background and sound effects. Preferences are saved in the browser.

No new dependencies. Run `npm run reset` once so the data reloads.

## New in 4.0 (light theme, pencil cursor, learning features)
- **Look**: soft light palette, Figtree + Bricolage Grotesque, pencil cursor with a graphite trail, wave ripples on every click, drifting wave footer. Dark mode still works.
- **Memory Health** (nav): 0-100 score = recent accuracy 45% + consistency 25% + retention 30%, with an improving/slipping badge and a 14-day trend.
- **Study Battle**: 2-6 players, same 10 questions from your decks, 60 s each, XP + badges, saved in the browser.
- **AI Flashcards**: PDF / .txt / pasted notes -> Q&A, multiple choice, definitions, notes; save into a new deck.
- **Exam Planner**: date + subjects + minutes/day; weak subjects and due cards weighted; "I missed this" re-plans.
- **Timers**: 1 min to 2 hours plus custom.
- **Explain this to me** button on every study card; rating below 3 opens a mistake coach (why, misconception, memory trick, practice question).
- **AI**: `ANTHROPIC_API_KEY=... npm start` (Node 18+) enables real AI for generation, explanations and coaching. Without a key, built-in rules are used.

## New in 5.0 (architecture, security, reliability, insights)

### Architecture
```
server/
  server.js        entry point: starts the app, graceful shutdown, crash logging
  app.js           createApp(store): middleware order + route mounting (testable without a port)
  config.js        every limit and setting in one place (env overridable)
  domain.js        pure helpers: ranking, card states, deck stats
  sm2.js           SM-2 scheduling (validated, injectable date)
  csv.js           CSV/Anki parser + formula-injection-safe writer
  validate.js      input validators that throw 400s
  store/           base.js (all-or-nothing updates) + json-store.js + sqlite-store.js
  middleware/      security headers + CSRF guard, rate limiter, error handling
  routes/          decks, study, tests, io, insights, ai
test/              unit + API tests (node:test, zero dependencies)
```
Layers: routes (HTTP) -> domain/validation (rules) -> store (persistence). Swapping the database touches only `store/`.

### Security
- Strict **Content-Security-Policy** (no inline scripts; the 12 inline `onclick` handlers were replaced by one delegated handler), plus `X-Frame-Options`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`, COOP/CORP, `no-store` on API responses, no `X-Powered-By`.
- **CSRF protection**: cross-origin writes are rejected (Origin vs Host) and JSON content type is required.
- **Rate limiting** per IP: reads, writes and (stricter) AI calls, with `429` + `Retry-After`.
- **Input validation** on every route: types, lengths (deck 80, card 2000), ids, grades, body size (2 MB), CSV rows (1000).
- **CSV formula injection** blocked on export (`=`, `+`, `-`, `@` cells are prefixed) and reversed on import; safe download filenames.
- **Test integrity**: answers are graded only against cards of that test's deck; duplicates and foreign cards are ignored; the answer key is never sent to the browser.
- AI key stays in an environment variable, server-side only; upstream error details are never returned to the client; 30 s timeout.
- Errors never leak stack traces: only deliberate messages reach the client.
- Known limit (by design for a single-user demo): there is no login; the current user is fixed in `config.js`. Add authentication before exposing it publicly.

### Reliability
- **Crash-safe writes**: temp file + fsync + atomic rename, previous version kept as `db.json.bak`; a corrupt file is moved aside and the backup restored.
- **All-or-nothing updates**: each write runs on a copy and is committed only if saving succeeds, so memory and disk never disagree.
- Async errors are caught; malformed JSON, oversized bodies, wrong content types and unknown routes all return clean JSON errors.
- `GET /api/health`, graceful shutdown on Ctrl+C / SIGTERM, friendly message if the port is taken.
- Browser side: 20 s request timeout, clear messages for offline / timeout / rate limit, global handler for unhandled errors, a fixed leaking timer in Memory Health.

### Features added
- **Manage cards** (deck card -> *Manage cards*): edit or delete cards, delete a deck. Editing keeps the SM-2 schedule.
- **Insights** (nav): 7-day review forecast, predicted recall today (forgetting curve), and **leech detection** (cards failed 4+ times) with a one-click *Fix card*.
- New API: `PUT/DELETE /api/cards/:id`, `PUT/DELETE /api/decks/:id`, `GET /api/insights`, `GET /api/health`.
- Fixed: Anki files that begin with a `#` header line were parsed with the wrong delimiter.

### Tests
`npm test` runs 29 tests: SM-2 maths, CSV parsing and injection safety, crash recovery and rollback of the store, SQLite persistence, and the HTTP API (validation, CSRF, rate limit, grading integrity, AI proxy with a mocked upstream).
